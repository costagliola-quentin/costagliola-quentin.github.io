# -*- coding: latin-1 -*-
################################################################################
#           IMPORTS
################################################################################
import os, sys, functools, datetime, platform
from steve_style import style
from PySide2 import QtGui, QtWidgets, QtCore
################################################################################
#           VARIABLES
################################################################################

################################################################################
#           PATH
################################################################################
MAINDIR = os.path.dirname(os.path.realpath(__file__))
ICONDIR = MAINDIR+'/ressources/images//icons/'
os.chdir(MAINDIR)
METAD = MAINDIR+'/metadata/'
################################################################################
#           MAIN CLASS
################################################################################
class widgets(object):
    """here all widgets are defined."""
    ############################################################################
    #           GLOBAL VARIABLES
    ############################################################################
    group_box_size = {
            "note_size_min_x" : 800,
            "wip_infos_size_max_x": 200,
            "wip_size_max_x": 200,
            "folder_size_max_x": 300}
    ############################################################################
    #           MAIN WINDOW
    ############################################################################

    def menuBar(self):
        #define menu bar
        self.menuBar = QtWidgets.QMenuBar(self)

        #file
        self.file_menuBar = self.menuBar.addMenu('File')
        #self.file_menuBar.setStyleSheet(str(win_props["background_color"]))
        self.manageProject_btn_Action = QtWidgets.QAction(QtGui.QIcon(ICONDIR+'set_project.ico'), 'Manage projects', self)
        self.manageProject_btn_Action.triggered.connect(functools.partial(self.open_manageProject_Action))
        self.manageProject_btn_Action.setShortcut("Ctrl+O")
        self.manageProject_btn_Action.setObjectName(('objectTest'))
        self.manageProject_btn_Action.setIcon(QtGui.QIcon(ICONDIR+'manageWIP_x32_icon.png'))
        self.quit_btn_Action = QtWidgets.QAction(QtGui.QIcon(ICONDIR+'set_project.ico'), 'Quit', self)
        self.quit_btn_Action.triggered.connect(functools.partial(self.quit_app_action))
        self.quit_btn_Action.setShortcut("Ctrl+Q")
        self.file_menuBar.addAction(self.manageProject_btn_Action)
        self.file_menuBar.addAction(self.quit_btn_Action)


        #edit
        self.edit_menuBar = self.menuBar.addMenu('Edit')
        self.open_hotkeys_btn_Action = QtWidgets.QAction(QtGui.QIcon(ICONDIR+'set_project.ico'), 'Hotkeys', self)
        self.open_hotkeys_btn_Action.triggered.connect(functools.partial(self.open_hotkeys_action))
        self.open_hotkeys_btn_Action.setShortcut("Ctrl+H")
        self.open_settings_btn_Action = QtWidgets.QAction(QtGui.QIcon(ICONDIR+'set_project.ico'), 'Settings', self)
        self.open_settings_btn_Action.triggered.connect(functools.partial(self.open_settings_action))
        self.open_settings_btn_Action.setShortcut("Ctrl+P")
        self.edit_menuBar.addAction(self.open_hotkeys_btn_Action)
        self.edit_menuBar.addAction(self.open_settings_btn_Action)
        #tools
        self.tools_menuBar = self.menuBar.addMenu('Tools')
        #view
        self.view_menuBar = self.menuBar.addMenu('View')
        #help
        self.help_menuBar = self.menuBar.addMenu('Help')
        self.about_btn_Action = QtWidgets.QAction(QtGui.QIcon(ICONDIR+'set_project.ico'), 'About', self)
        self.about_btn_Action.triggered.connect(functools.partial(self.about_action))
        self.about_btn_Action.setShortcut("Ctrl+A")
        self.help_menuBar.addAction(self.about_btn_Action)

        self.web = self.help_menuBar.addMenu('Web')
        self.web.setIcon(QtGui.QIcon(ICONDIR+'firefox_icon.png'))
        self.PySide2Help_btn_Action = QtWidgets.QAction(QtGui.QIcon(ICONDIR+'set_project.ico'), 'PySide2', self)
        self.PySide2Help_btn_Action.triggered.connect(functools.partial(QtGui.QDesktopServices.openUrl, QtCore.QUrl('https://doc.qt.io/qtforpython/')))
        self.QtCoreQt_btn_Action = QtWidgets.QAction(QtGui.QIcon(ICONDIR+'set_project.ico'), 'QtCore.Qt', self)
        self.QtCoreQt_btn_Action.triggered.connect(functools.partial(QtGui.QDesktopServices.openUrl, QtCore.QUrl('https://doc.qt.io/qtforpython/PySide2/QtCore/Qt.html')))

        self.web.addAction(self.PySide2Help_btn_Action)
        self.web.addAction(self.QtCoreQt_btn_Action)
        return self.menuBar

    def toolBar(self):
        self.toolBar = QtWidgets.QToolBar()
        self.selectStyleSheet = QtWidgets.QComboBox()
        self.selectStyleSheet.addItem('Bridge')
        self.selectStyleSheet.addItem('Atom')

        self.selectStyleSheet.activated[str].connect(self.selectStyleSheet_Action)
        self.toolBar.addWidget(self.selectStyleSheet)
        return self.toolBar

    def switchBtnListBar(self):
        layout = QtWidgets.QHBoxLayout()

        btn_list = []
        btn_group = QtWidgets.QButtonGroup()
        for i in range (0, 5):
            btn_list.append(QtWidgets.QPushButton(text=str(i)))
            btn_list[i].setObjectName('switch')
            layout.addWidget(btn_list[i])
            btn_group.addButton(btn_list[i])
            btn_list[i].clicked.connect(functools.partial(self.feedbacks,str(i), 'CONSOLE'))

        #layout.addWidget(btn_group)
        groupbox = QtWidgets.QGroupBox()
        groupbox.setFixedHeight(20)
        groupbox.setLayout(layout)

        return groupbox



    def noteTabWidget(self, ACTIVEwip):
        #   DEFINE OBJECTS
        notewidget = QtWidgets.QWidget()
        #   DEFINE LAYOUTS
        layoutH1 = QtWidgets.QHBoxLayout(notewidget)      #cree un layout pour y mettre le notepad
        layoutH1.addSpacing(10)
        #layoutH1.insertSpacing(1, 100)
        layout_left = QtWidgets.QVBoxLayout()
        layout_right = QtWidgets.QVBoxLayout()

        #   OBJECTS PROPERTIES
        wipList = wipnotesTab.wipGroupBox(self)
        wipFolders = wipnotesTab.foldersGroupBox(self)
        wipInfos = wipnotesTab.wipInfoGroupBox(self)

        notewidget.setObjectName('tabBar')
        self.notePad = QtWidgets.QTextEdit()        #editeur de texte
        self.notePad.setFont(QtGui.QFont("Segoe UI", 11))
        self.notePad.setObjectName('WIPnotes')
        self.notePad.setPlainText(self.pickWIPnotes(ACTIVEwip))
        #save text into files CTRL+S
        shortcut_save = QtWidgets.QShortcut(QtGui.QKeySequence("Ctrl+S"), self)
        shortcut_save.activated.connect(self.saveAction)
        #   POPULATE LAYOUTS
        layoutH1.addLayout(layout_left)
        layoutH1.addWidget(self.notePad)            #on ajoute le notepad au layout
        layoutH1.addLayout(layout_right)
        layout_left.addWidget(wipList)
        layout_right.addWidget(wipFolders)
        layout_right.addWidget(wipInfos)
        #   SETUP WIDGET

        return notewidget

    def rpgTabWidget(self):

        """
        widget = QtWidgets.QMainWindow()
        #widget.setDockOptions(widget.GroupedDragging | widget.AllowTabbedDocks)

        layout = QtWidgets.QVBoxLayout(widget)
        btn = QtWidgets.QPushButton('button')
        widget.setLayout(layout)
        layout.addWidget(btn)

        dock = QtWidgets.QDockWidget('Dock widget', widget)
        self.listWidget = QtWidgets.QListWidget()
        self.listWidget.addItem("item1")
        self.listWidget.addItem("item2")
        self.listWidget.addItem("item3")
        dock.setGeometry(100,100, 100, 100)
        dock.setFeatures(QtWidgets.QDockWidget.DockWidgetMovable)
        #dock.initStyleOption(QtWidgets.QStyleOptionDockWidget(1))

        dock.setWidget(self.listWidget)

        dock1 = QtWidgets.QDockWidget('Dock widget1', widget)
        self.tab = QtWidgets.QTabWidget()
        dock1.setGeometry(0,0, 100, 100)
        dock1.setFeatures(QtWidgets.QDockWidget.DockWidgetMovable)
        dock1.setWidget(self.tab)

        dock2 = QtWidgets.QDockWidget('Dock widget2', widget)
        self.tab1 = QtWidgets.QTabWidget()
        dock2.setGeometry(200,200, 100, 100)
        dock2.setFeatures(QtWidgets.QDockWidget.DockWidgetMovable)
        dock2.setWidget(self.tab1)

        widget.addDockWidget=(QtCore.Qt.AllDockWidgetAreas, dock,)
        widget.addDockWidget=(QtCore.Qt.AllDockWidgetAreas, dock1)
        widget.addDockWidget=(QtCore.Qt.AllDockWidgetAreas, dock2)
        """

        tab = rpgTab()

        return tab

    def tabsWidget(self, ACTIVEwip):
        tabwidget = QtWidgets.QTabWidget()
        tabwidget.setMovable(True)
        #tabwidget.setTabsClosable(False)
        #tabwidget.setUsesScrollButtons(False)
        #tabwidget.setTabEnabled(1, False)
        tabwidget.setTabPosition(QtWidgets.QTabWidget.North)
        #tabwidget.setTabShape(QtWidgets.QTabWidget.Triangular)     # ou Rounded
        self.welcomewidget = welcomeTab.welcomewidget(self)
        self.noteTabwidget = widgets.noteTabWidget(self, ACTIVEwip)
        refwidget = QtWidgets.QWidget()
        refwidget.setObjectName('tabBar')
        databasewidget = QtWidgets.QWidget()
        databasewidget.setObjectName('tabBar')
        pipewidget = QtWidgets.QWidget()
        pipewidget.setObjectName('tabBar')
        dicowidget = QtWidgets.QWidget()
        dicowidget.setObjectName('tabBar')
        self.rpgwidget = widgets.rpgTabWidget(self)
        self.rpgwidget.setObjectName('tabBar')

        welcometab = tabwidget.addTab(self.welcomewidget, 'Welcome')
        notestab = tabwidget.addTab(self.noteTabwidget, 'Notes')
        referencestab = tabwidget.addTab(refwidget, 'References')
        pipetab = tabwidget.addTab(pipewidget, 'Pipe')
        databasetab = tabwidget.addTab(databasewidget, 'Database')
        dicotab = tabwidget.addTab(dicowidget, 'Dico')
        rptab = tabwidget.addTab(self.rpgwidget, 'RPG')
        return tabwidget

    def commandLineGroup(self):
        #COMMAND LINE
        self.commandLine_group = QtWidgets.QGroupBox('')
        self.commandLine_group.setObjectName('commandLine')
        self.commandLine_layout = QtWidgets.QVBoxLayout(self.commandLine_group)
        self.commandLine_notePad = QtWidgets.QTextEdit()
        self.commandLine_notePad.setObjectName('commandLine')

        self.commandLine_group.setFixedHeight(40)
        #self.commandLine_notePad.setReadOnly(True)
        self.commandLine_notePad.setEnabled(False)

        self.commandLine_layout.addWidget(self.commandLine_notePad)
        return self.commandLine_group



    ############################################################################
    #           SECONDS TABS
    ############################################################################



class welcomeTab(object):
    """docstring for welcomeTab."""

    def __init__(self):
        super(welcomeTab, self).__init__()

    def welcomewidget(self):
        self.welcomewidget = QtWidgets.QWidget()
        self.welcomewidget.setObjectName('tabBar')

        #   DEFINE LAYOUTS
        layout = QtWidgets.QVBoxLayout()
        #   LAYOUTS PROPERTIES
        #   DEFINE OBJECTS
        self.label=QtWidgets.QLabel(self)
        self.label.setScaledContents(True)
        self.label.setSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Maximum )
        self.pixmap = QtGui.QPixmap(MAINDIR+'/ressources/images/welcome.png')
        self.pixmap = self.pixmap.scaled(self.welcomewidget.width()*1.5, self.welcomewidget.height()*1.5, QtCore.Qt.KeepAspectRatio)
        self.label.resizeEvent = functools.partial(self.welcomeOnResize)
        #label.resizeEvent = label.setPixmap(pixmap.scaled(100,100, QtGui.Qt.KeepAspectRatio, QtGui.Qt.SmoothTransformation))
        print(self.width())
        #pixmap.setPixmap(QtCore.Qt.KeepAspectRatio)
        self.label.setPixmap(self.pixmap)

        #   OBJECTS PROPERTIES
        #   POPULATE LAYOUTS
        layout.addStretch()
        layout.addWidget(self.label, alignment=QtCore.Qt.AlignJustify)
        layout.addStretch()
        #layout.addWidget(pixxmap)
        layout.addStretch()
        #   SETUP WIDGET
        self.welcomewidget.setLayout(layout)

        return self.welcomewidget


class wipnotesTab(object):
    """docstring for wipnotes."""

    def __init__(self):
        super(wipnotesTab, self).__init__()

    def manageWIPwidget(self):
        #   DEFINE LAYOUTS
        layout_h1 = QtWidgets.QVBoxLayout()
        layout_h1.insertSpacing(2, 10)

        layout_add = QtWidgets.QHBoxLayout()
        addWIPgroup = QtWidgets.QGroupBox()
        addWIPgroup.setObjectName('manageWIP')
        addWIPgroup.setLayout(layout_add)
        addtext = QtWidgets.QLabel('Add WIP : ')
        layout_add.addWidget(addtext)
        id_linedit = QtWidgets.QLineEdit('ID')
        id_linedit.setObjectName('manageWIP')
        layout_add.addWidget(id_linedit)
        name_linedit = QtWidgets.QLineEdit('name')
        name_linedit.setObjectName('manageWIP')
        layout_add.addWidget(name_linedit)
        path_linedit = QtWidgets.QLineEdit('path')
        path_linedit.setObjectName('manageWIP')
        layout_add.addWidget(path_linedit)
        layout_add.addStretch()

        layout_remove = QtWidgets.QHBoxLayout()                                      #pour le groupbox
        removeWIPgroup = QtWidgets.QGroupBox()
        removeWIPgroup.setObjectName('manageWIP')
        removeWIPgroup.setLayout(layout_remove)
        removetext = QtWidgets.QLabel('Remove WIP : ')
        layout_remove.addWidget(removetext)
        name_linedit = QtWidgets.QLineEdit('name')
        name_linedit.setToolTip('Enter a name or an ID')
        name_linedit.setObjectName('manageWIP')
        layout_remove.addWidget(name_linedit)
        layout_remove.addStretch()

        layout_h1.addWidget(addWIPgroup)
        layout_h1.addWidget(removeWIPgroup)

        #   SETUP WIDGET
        manageW = QtWidgets.QWidget()
        manageW.setStyleSheet("background:#323232")
        manageW.setLayout(layout_h1)

        return manageW

    def wipGroupBox(self):
        #   DEFINE LAYOUTS
        self.alone_lyt_2 = QtWidgets.QVBoxLayout()  #pour corriger le bug avec le label
        #   LAYOUTS PROPERTIES
        #   DEFINE OBJECTS
        self.wip_groupbox = QtWidgets.QGroupBox("WIP")
        self.void_lb = QtWidgets.QLabel(' ')
        self.wip_list = QtWidgets.QListWidget(self.wip_groupbox)
        self.wipToolBar = QtWidgets.QToolBar()
        self.addWIP_btn = QtWidgets.QPushButton()
        self.removeWIP_btn = QtWidgets.QPushButton()
        self.manageWIP_btn = QtWidgets.QPushButton()
        self.refreshWIP_btn = QtWidgets.QPushButton('Refresh')

        #   OBJECTS PROPERTIES
        self.wip_groupbox.setFixedWidth(self.group_box_size["wip_size_max_x"])            #set fixed width
        self.wip_list.setObjectName('mygrey')
        self.addWIP_btn.setObjectName('iconOnly')
        self.addWIP_btn.clicked.connect(self.addwip)
        self.removeWIP_btn.setObjectName('iconOnly')
        self.removeWIP_btn.clicked.connect(self.removewip)
        self.manageWIP_btn.setObjectName('iconOnly')
        self.manageWIP_btn.clicked.connect(functools.partial(self.open_manageProject_Action))
        self.refreshWIP_btn.setObjectName('normal')
        self.refreshWIP_btn.clicked.connect(self.refreshwip)
        self.wip_list.setFont(QtGui.QFont("Segoe UI", 10))
        self.testitemList = []
        for i in range(0, len(self.WIPs)):
            self.testitemList.append(QtWidgets.QListWidgetItem(QtGui.QIcon(ICONDIR+'orange_icon.ico'), self.WIPs[str(i)]['name']))
            self.wip_list.addItem(self.testitemList[i])  #gère seulement le nom du wip list
            wip_inst = wip(wip_metadata=self.WIPs[str(i)])
        self.wip_list.setCurrentRow(0)  #sélectionne le 1° projet lors de l'ouverture du projet
        self.wip_list.clicked.connect(self.setup_current_WIP)
        self.addWIP_btn.setIcon(QtGui.QIcon(ICONDIR+'addWIP_x32_icon.png'))
        self.addWIP_btn.setFlat(True)
        self.removeWIP_btn.setIcon(QtGui.QIcon(ICONDIR+'removeWIP_x32_icon.png'))
        self.removeWIP_btn.setFlat(True)
        self.manageWIP_btn.setIcon(QtGui.QIcon(ICONDIR+'manageWIP_x32_icon.png'))
        self.manageWIP_btn.setFlat(True)


        #   POPULATE LAYOUTS
        self.wipToolBar.addWidget(self.addWIP_btn)
        self.wipToolBar.addWidget(self.removeWIP_btn)
        self.wipToolBar.addWidget(self.manageWIP_btn)
        self.wipToolBar.addWidget(self.refreshWIP_btn)
        self.alone_lyt_2.addWidget(self.void_lb)
        self.alone_lyt_2.addWidget(self.wip_list)
        self.alone_lyt_2.addWidget(self.wipToolBar)
        #   SETUP WIDGET
        self.wip_groupbox.setLayout(self.alone_lyt_2)

        return self.wip_groupbox

    def wipInfoGroupBox(self):
        #WIP_infos
        wip_infos_groupbox = QtWidgets.QGroupBox("WIP infos")
        wip_infos_groupbox.setFixedWidth(self.group_box_size["wip_infos_size_max_x"])

        #wip infos content
        self.label2 = QtWidgets.QLabel('')
        self.selected_wip_name = QtWidgets.QLabel('Name : ')
        self.selected_wip_id = QtWidgets.QLabel('ID : ')
        self.selected_wip_path = QtWidgets.QLabel('Path : ')
        self.selected_wip_path.setToolTip('path')
        self.selected_wip_mainRef = QtWidgets.QLabel('Main ref : ')
        self.statusBar_wipInfos = QtWidgets.QStatusBar(wip_infos_groupbox)

        self.statusBar_wipInfos.showMessage('Wips : ' + str(wip.nombreDeWip), timeout=0)  #timeout = temps d'affichage du message (0: affiche le message jusqu a la commmande clearMessage())
        self.statusBar_wipInfos.show()
        #wip infos layouts
        self.alone_lyt_3 = QtWidgets.QVBoxLayout()
        self.alone_lyt_3.addWidget(self.label2)
        self.alone_lyt_3.addWidget(self.selected_wip_name)
        self.alone_lyt_3.addWidget(self.selected_wip_id)
        self.alone_lyt_3.addWidget(self.selected_wip_path)
        self.alone_lyt_3.addWidget(self.selected_wip_mainRef)
        self.alone_lyt_3.addStretch()
        self.alone_lyt_3.addWidget(self.statusBar_wipInfos)
        wip_infos_groupbox.setLayout(self.alone_lyt_3)
        return wip_infos_groupbox

    def foldersGroupBox(self):
        #FOLDERS
        #   define
            #   groupbox
        folders_groupbox = QtWidgets.QGroupBox("Folders")
        folders_groupbox.setFixedWidth(self.group_box_size["folder_size_max_x"])
            #   layout
        self.folders_lyt_h1 = QtWidgets.QVBoxLayout()
            #   content
        self.label = QtWidgets.QLabel('')
        self.treeView = QtWidgets.QTreeView()
        self.definetreeView()          #tree widget géré dans sa fonction
        #   populate
        folders_groupbox.setLayout(self.folders_lyt_h1)
        self.folders_lyt_h1.addWidget(self.label)
        self.folders_lyt_h1.addWidget(self.treeView)
        return folders_groupbox

class rpgTab(QtWidgets.QMainWindow):
    """docstring for rpgTab."""

    def __init__(self):
        super(rpgTab, self).__init__()
        self.setObjectName('rpg')
        self.setStyleSheet(style.bridge_StyleSheet(self))
        #pour que le dock fonctionne il faut set central widget
        mainDockWidget = QtWidgets.QDockWidget('Main', self)
        mainWidget = QtWidgets.QWidget()
        mainLayout = QtWidgets.QVBoxLayout(mainWidget)
        textEdit=QtWidgets.QTextEdit()
        mainLayout.addWidget(textEdit)
        mainDockWidget.setWidget(mainWidget)
        self.addDockWidget(QtGui.Qt.AllDockWidgetAreas, mainDockWidget)

        self.setCentralWidget(mainWidget)

        rpListDockWidget = QtWidgets.QDockWidget('RPG list', self)
        rpList = QtWidgets.QListWidget()
        rpList.addItem('rp1')
        rpList.addItem('rp2')
        rpList.addItem('rp3')
        rpListDockWidget.setWidget(rpList)
        rpListDockWidget.setFloating(False)
        self.addDockWidget(QtGui.Qt.LeftDockWidgetArea, rpListDockWidget)       # le leftdock... permet de setup la location par default

        ressourcesDockWidget = QtWidgets.QDockWidget('Ressources', self)
        #ressources = QtWidgets.QListWidget
        self.addDockWidget(QtGui.Qt.LeftDockWidgetArea, ressourcesDockWidget)

        fileLiseDockWidget = QtWidgets.QDockWidget('Files', self)
        #ressources = QtWidgets.QListWidget
        self.addDockWidget(QtGui.Qt.LeftDockWidgetArea, fileLiseDockWidget)







class wip(object):
    """classe qui gère chaque wip et son contenu."""
    nombreDeWip=0
    #WIPs = steveUi.WIPs
    def __init__(self, wip_metadata):
        super(wip, self).__init__()
        wip.nombreDeWip+=1
        self.id = wip_metadata["id"]
        self.name = wip_metadata["name"]
        self.path = wip_metadata["path"]


















#   DEFINE LAYOUTS
#   LAYOUTS PROPERTIES
#   DEFINE OBJECTS
#   OBJECTS PROPERTIES
#   POPULATE LAYOUTS
#   SETUP WIDGET
