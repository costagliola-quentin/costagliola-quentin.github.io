# -*- coding: latin-1 -*-
################################################################################
#           IMPORTS
################################################################################
import os, sys, functools, datetime, platform
from PySide2 import QtGui, QtWidgets, QtCore
from steve_style import style
from steve_widgets import widgets, wip, wipnotesTab

################################################################################
#           VARIABLES
################################################################################
debug=True
console=True
WIPs = {}
ACTIVEwip = {"id":'0000', 'name': 'name', 'path':'path', 'mainRef':'artStation'}           #initialisé par défault sur woody (pas très procedural faudra changer) => faire une page d'accueil
win_props = {
    "size_x":1280,
    "size_y":720,
    "location_x":0,   #800
    "location_y":0,   #400
    "background_color":"QMainWindow {background: rgb(40,44,52)}",
    "front_color":"background : rgb(34,38,46);",
    }
################################################################################
#           PATH
################################################################################
MAINDIR = os.path.dirname(os.path.realpath(__file__))
ICONDIR = MAINDIR+'/ressources/images//icons/'
os.chdir(MAINDIR)
METAD = MAINDIR+'/metadata/'
################################################################################
#           MAIN CLASS
################################################################################
class steveUi(QtWidgets.QMainWindow):
    """docstring for steveUi."""
    ############################################################################
    #           GLOBAL VARIABLES
    ############################################################################
    global ACTIVEwip

    group_box_size = {
            "note_size_min_x" : 800,
            "wip_infos_size_max_x": 200,
            "wip_size_max_x": 200,
            "folder_size_max_x": 300}
    def __init__(self):
        super(steveUi, self).__init__()

        #cursor.setPos(Qt.ImAnchorPosition)
        self.define_wip_metadata()  #crée le dictionnaire   WIPs
        self.steve_WIN_props()   #main window props

        self.window_content()       #main window wontent
        self.setCursor(QtGui.QCursor(QtGui.QPixmap(ICONDIR+'cursor_icon.png')))
        self.setStyleSheet(style.bridge_StyleSheet(self))

        self.setup_current_WIP()    #initialise tout
        self.show()                 #show window

    def steve_WIN_props(self):
        self.setWindowTitle('Steve')
        self.setGeometry(win_props["location_x"], win_props["location_y"], win_props["size_x"], win_props["size_y"])
        self.setWindowIcon(QtGui.QIcon("ressources/images/icons/set_project.ico"))


    ##############################
    #   FONCTIONS RECURRENTES
    ##############################
    def listToString(self, list):
        new_string = ""
        return new_string.join(list)

    def removeFromString(self, string, toRemove):
        '''remove les caracteres entrés en toRemove le la chaine de caractere string'''
        list = []
        for i in range (0, len(string)):
            list.append(string[i])
        list.remove(toRemove)
        new_string = ""
        return new_string.join(list)

    def stringToList(self, string):
        return string.split(" ")

    def saveAction(self):
        """save entered text into files when hit Ctrl+S"""
        self.feedbacks(message=('OK', self.ACTIVEwip), messageType='debug')
        with open(self.ACTIVEwip["id"]+'.txt', 'w') as notes_f:
            self.fileContent = self.notePad.toPlainText()
            self.feedbacks(str(self.fileContent), 'debug')
            notes_f.write(self.fileContent)
        self.feedbacks('saved', 'console')

    def feedbacks(self, message='', messageType=''):
        message = str(message)
        messageType = messageType.upper()
        if messageType == 'CONSOLE':    #debugg propre
            message = message.upper()
        if messageType == 'debug':
            message = message.lower()
        if debug==True and messageType == 'DEBUG':
                print (messageType + "   >>>    " + message)
        if console==True and messageType == 'CONSOLE':
                print(messageType + "   >>>    " + message)
                try:
                    self.commandLine_notePad.setPlainText(message)
                except:
                    pass
                try:
                    widgets.commandLine_notePad.setPlainText(message)
                except:
                    pass


    ##############################
    #   POPULATE
    ##############################

    def context_menu(self):
        menu = QtWidgets.QMenu()
        open = menu.addAction('Open')
        open.triggered.connect(self.open_file)
        cursor = QtGui.QCursor()    #get the position of the cursor
        menu.exec_(cursor.pos())

    def open_file(self):
        index = self.treeView.selectedIndexes()[0]
        #crawler = index.model().itemFromIndex(index)
        selected = self.treeView.selectedItem()
        print(crawler)

    def definetreeView(self):
        path = ''
        uname = platform.uname()
        if uname[1]=='DESKTOP-E0FSJID':
            path = 'D:/VFX/Projects/Work_In_Progress'
        else :
            path = 'C:/Users/Cosius/Documents/WIP'


        self.model = QtWidgets.QFileSystemModel()
        self.model.setRootPath(QtCore.QDir.rootPath())
        self.model.setNameFilterDisables(False)

        #
        self.treeView.setColumnWidth(0,50)
        self.treeView.setAllColumnsShowFocus(True)
        self.treeView.setModel(self.model)
        self.treeView.setRootIndex(self.model.index(path))
        self.treeView.setSortingEnabled(True)
        self.treeView.sortByColumn(0, QtCore.Qt.AscendingOrder)
        self.treeView.sortByColumn(1, QtCore.Qt.DescendingOrder)
        self.treeView.setIndentation(15)
        self.treeView.resize(50, 500)
        self.treeView.setColumnHidden(1, True)
        self.treeView.setColumnHidden(2, True)
        self.treeView.setColumnHidden(3, True)
        self.treeView.setHeaderHidden(True)

        self.treeView.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.treeView.customContextMenuRequested.connect(self.context_menu)
        self.treeView.clicked.connect(self.open_file)




    ##############################
    #   ACTIONS
    ##############################
    def define_wip_metadata(self):  #crée le dictionnaire
        H2 = {}
        with open(METAD+'/wip.txt', 'r') as wip_f:
            f = wip_f.readlines()   #variable contenant TOUT LE FICHIER
            #print(f)
            for i in range(0, len(f)):
                #on enlève les \n
                tempString = self.removeFromString(string=f[i], toRemove='\n')
                #tempString.split(' ')
                #print('tempstring : ', tempString)
                #on converti la string en liste
                list=self.stringToList(tempString)
                #print('list : ', list)
                #on ajoute la liste au dico H1
                H1 = {"id": list[0], "name": list[1], "path": list[2], "mainRef": list[3]}
                #on ajoute le contenu du dictionnaire H1 au dico H2
                H2[str(i)]=H1
        #print("H2 : ", H2)
        #print('H1 : ',H1)
        steveUi.WIPs = H2
        #print('WIPs : ', self.WIPs)

    def quit_app_action(self):
        """quit application"""
        self.close()
        try :
            self.manageProject_win.close()
            self.win_settings.close()
            self.win_about.close()
        except RuntimeError:
            pass
        except AttributeError:
            pass

    def open_hotkeys_action(self):
        """open settings window"""
        #window content
        hotkey_lyt_h1=QtWidgets.QFormLayout()

        hotkeysNames = ["Hotkeys editor", "Settings"]
        hotkeysHotkeys = ["Ctrl+H", "Ctrl+P"]
        for i in range (0, len(hotkeysNames)):

            hotkeylabel = QtWidgets.QLabel(hotkeysHotkeys[i])
            hotkey_lyt_h1.addWidget(hotkeylabel)
            hotkey_lyt_h1.addRow(hotkeysNames[i], hotkeylabel)

        openhotkeyswin_lb_1 = QtWidgets.QLabel('hotkeys')
        hotkey_lyt_h1.addWidget(openhotkeyswin_lb_1)
        #hotkey_lyt_h1.addStretch()
        #window instance
        self.win_manageProjects = subwin(
            winTitle='Hotkeys',
            styleSheet=style.atom_StyleSheet(subwin),
            size=[700, 500],
            layout=hotkey_lyt_h1,
        )
        self.feedbacks('Hotkeys editor', 'console')

    def open_manageProject_Action(self):
        """add a project from file/folder to the wip folder"""
        #window content
        mpwin_lyt_h1=QtWidgets.QVBoxLayout()
        groupbox = wipnotesTab.manageWIPwidget(self)
        mpwin_lyt_h1.addWidget(groupbox)

        #window instance
        self.win_manageProjects = subwin(
            winTitle='Manage projects',
            styleSheet=style.bridge_StyleSheet(subwin),
            size=[500, 250],
            layout=mpwin_lyt_h1,
        )

        self.feedbacks('Manage projects', 'console')

    def open_settings_action(self):
        """open settings window"""
        #window content
        oswin_lyt_h1=QtWidgets.QVBoxLayout()
        cosius_label = QtWidgets.QLabel('Settings')
        oswin_lyt_h1.addWidget(cosius_label)
        oswin_lyt_h1.addStretch()
        #window instance
        self.win_settings = subwin(
            winTitle='Settings',
            styleSheet=style.atom_StyleSheet(subwin),
            size=[700, 500],
            layout=oswin_lyt_h1,
        )
        self.feedbacks('Settings', 'console')

    def about_action(self):
        """about window"""
        #window content
        awin_lyt_h1=QtWidgets.QVBoxLayout()
        cosius_label = QtWidgets.QLabel('about')
        awin_lyt_h1.addWidget(cosius_label)
        awin_lyt_h1.addStretch()
        #window instance
        self.win_about = subwin(
            winTitle='About',
            styleSheet=style.atom_StyleSheet(subwin),
            size=[600,200],
            layout=awin_lyt_h1,
        )

    def setup_current_WIP(self):
        currentItem = self.wip_list.currentItem()
        currentItemName = currentItem.text()    #regarde le nom du wip duquel on vient de cliquer
        for i in range(0, len(self.WIPs)):  #boucle qui regarde dans le dico contenant TOUS les wips si le nom de la selection est le meme que le nom contenu dans chaue iteration du dico
            #print('current name : ',currentItemName)  #le nom du wip qu'on vient de cliquer
            #print('i :',self.WIPs[str(i)])

            if self.WIPs[str(i)]["name"] == currentItemName: #test
                ACTIVEwip = self.WIPs[str(i)]
                break   #arrete la boucle des qu'on a trouvé le bon
        self.feedbacks('ACTIVEwip : ' + str(ACTIVEwip), 'console')
        #ACTIVE WIP INITIALISATION
        self.ACTIVEwip = ACTIVEwip
        #set les bons labels des WIP infos
        self.selected_wip_name.setText('Name : '+ACTIVEwip['name'])
        self.selected_wip_id.setText('ID : '+ACTIVEwip['id'])
        self.selected_wip_path.setText('Path : '+ACTIVEwip['path'])
        self.selected_wip_mainRef.setText('Main ref : '+ACTIVEwip['mainRef'])
        self.selected_wip_path.setToolTip(ACTIVEwip['path'])
        for i in range (0,len(self.WIPs)):                                      #set icon fow each item of the list
            self.testitemList[i].setIcon(QtGui.QIcon(self.WIPs[str(i)]['path']+'\icon.ico'))

        self.notePad.setPlainText(self.pickWIPnotes(ACTIVEwip))
        self.treeView.setRootIndex(self.model.index(ACTIVEwip["path"]))

    def pickWIPnotes(self, ACTIVEwip):
        """va chercher le contenu des fichers correspondant aux IDs des projets et l'affiche dans le notePad"""
        os.chdir(MAINDIR + "/metadata/notes/")

        try:        #si le ficier existe pas il le crée                         #pour qu'il crée le fichier s'il n'existe pas il faut qu'il soit en w mode (le + c'est pour qu'il lise aussi)
            open(ACTIVEwip["id"]+'.txt', 'r')
        except FileNotFoundError:
            f= open(ACTIVEwip["id"]+'.txt',"w+")    #
            f.close()
        with open(ACTIVEwip["id"]+'.txt', 'r') as notes_f:                      #si je met w+ il m'écrase le fichier
            f = notes_f.read()
        return str(f)

    def selectStyleSheet_Action(self, styleSheet):
        """Slot qui change le stylesheet"""
        if styleSheet == 'Atom':
            self.feedbacks('StyleSheet selected : Base', 'console')
            self.setStyleSheet(style.atom_StyleSheet(self))
        if styleSheet == 'Bridge':
            self.feedbacks('StyleSheet selected : Bridge', 'console')
            self.setStyleSheet(style.bridge_StyleSheet(self))

    def welcomeOnResize(self, arg):
        #self.welcomewidget.size()
        #size = pixmap.size()
        #print(pixmap.size())
        #self.welcomewidget.resize(500, 500)
        print(self.size())
        #self.label.setPixmap(self.pixmap.scaled(size, QtGui.Qt.KeepAspectRatio, QtGui.Qt.SmoothTransformation))
        self.welcomewidget.adjustSize()
        self.label.adjustSize()
        self.label.setSizePolicy(QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Maximum )

    def addwip(self):
        """action done when + btn is clicked"""
        self.feedbacks('Add WIP', 'console')

    def removewip(self):
        """action done when - btn is clicked"""
        self.feedbacks('Remove WIP', 'console')

    def managewip(self):
        """action done when manage wip btn is clicked"""
        mpwin_lyt_h1=QtWidgets.QVBoxLayout()

        groupbox = widgets.manageWIPwidget(self)
        mpwin_lyt_h1.addWidget(groupbox)

        self.feedbacks('Manage WIP', 'console')

    def refreshwip(self):
        """to actualize the wip list after we added one"""
        self.feedbacks('Refresh WIPs', 'console')

    ############################################################################
    #           WINDOW CONTENT
    ############################################################################
    def window_content(self):
        #   DEFINE LAYOUTS
        layout_h1 = QtWidgets.QVBoxLayout()
        layout_h1_5 = QtWidgets.QHBoxLayout()
        layout_h2 = QtWidgets.QGridLayout()
        #   LAYOUTS PROPERTIES
        layout_h1.insertSpacing(0, -4)
        layout_h2.setColumnMinimumWidth(1, self.group_box_size["note_size_min_x"])
        layout_h2.setColumnMinimumWidth(2, 200)
        layout_h2.setRowMinimumHeight(0, 200)
        layout_h2.setRowMinimumHeight(1, 200)
        layout_h2.setRowMinimumHeight(2, 0)

        #   DEFINE INSTANCES
        self.menuBar = widgets.menuBar(self)
        self.toolBar = widgets.toolBar(self)
        #self.switch = widgets.switchBtnListBar(self)

        self.tabsWidget = widgets.tabsWidget(self, ACTIVEwip)

        self.commandLineGroup = widgets.commandLineGroup(self)

        #   POPULATE LAYOUTS
        layout_h1.addLayout(layout_h1_5)
        #layout_h1.addLayout(layout_h2)

        layout_h1_5.addWidget(self.menuBar)
        #layout_h1_5.addWidget(self.switch)
        layout_h1_5.addWidget(self.toolBar)

        layout_h1.addWidget(self.tabsWidget)
        layout_h1.addWidget(self.commandLineGroup)


        #   SETUP WIDGET
        steve_widget = QtWidgets.QWidget()
        steve_widget.setLayout(layout_h1)
        self.setCentralWidget(steve_widget)

class subwin(QtWidgets.QMainWindow):
    """docstring for subwin."""

    def __init__(self, winTitle, styleSheet, layout, winIconName="set_project.ico", location=[500, 150], size=[300, 300]):
        super(subwin, self).__init__()
        self.setWindowTitle(winTitle)
        self.setWindowIcon(QtGui.QIcon(ICONDIR+winIconName))
        self.setStyleSheet(style.bridge_StyleSheet(self))
        self.setGeometry(                                                       #pop au centre de Steve
            (win_props["location_x"] + win_props["size_x"]/2) - size[0]/2,
            (win_props["location_y"] + win_props["size_y"]/2) - size[1]/2,
            size[0],
            size[1]
        )
        self.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)   # |    QtCore.Qt.DragMoveCursor|QtCore.Qt.DragCopyCursor   QtCore.Qt.
        self.winProps(layout)
        self.show()

    def winProps(self, layout):
        #content
        self.label = QtWidgets.QLabel('debug')
        #layout
        self.lyt_h1 = QtWidgets.QVBoxLayout(self)
        self.lyt_h1.addWidget(self.label)
        self.lyt_h1.addStretch()
        #widget
        self.widget = QtWidgets.QWidget()
        #self.widget.setLayout(self.lyt_h1)
        self.widget.setLayout(layout)
        self.setCentralWidget(self.widget)

App = QtWidgets.QApplication(sys.argv)
#App.setStyleSheet(style.bridge_StyleSheet(App))
window = steveUi()
App.exec_()
sys.exit()

#       conda activate cosius_env2
#       python D:\VFX\Projects\Work_In_Progress\0067_python_steve\steve\steve_main.py
