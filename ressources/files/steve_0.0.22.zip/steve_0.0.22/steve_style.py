# -*- coding: latin-1 -*-
import os, sys, functools, datetime, platform
from PySide2 import QtGui, QtWidgets, QtCore

class style(object):
    """This is the module in wich one we will define all about style"""

    def atom_StyleSheet(self):
        #22262e : h2 : groupbox background
        #282c34 : h1 : main window background
        #abb2bf : text color
        self.stylesheet = """

        QMainWindow{
            color: red; /*  for debug */
            background: #282c34;
            cursor:url("http://www.javascriptkit.com/dhtmltutors/cursor-hand.gif") 10 3, auto;
        }

        QMenuBar{
            color: white;
            background: #22262e;
        }

        QGroupBox{
            color: white;
            background: #22262e;
            border-radius: 1px;
            border-width: 3px;
            border-style: solid;
            border-color: #22262e;
        }
        QListWidget{
            color: white;
            background: #22262e;
            border:2px;
        }

        QStatusBar{
            color: white;
        }

        QTextEdit{
            color: #abb2bf;
            background: #22262e;
            border-radius: 9px;

        }

        QListWidget#mygrey{
            color: #abb2bf;
        }

        QLabel{
            color: #abb2bf;
        }

        QStatusBar{
            color: #abb2bf;
        }

        QScrollBar:vertical {
            border: 0px;

            background: #22262e;
            width: 10px;
        }

        QScrollBar::handle:vertical {
            background: #282c34;
            border-radius: 4;

        }

        QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
            background: #22262e;
            border:0;
        }

        QToolTip{
            color: white;
            border: 0px;
            background: #282c34;
        }

        QTreeView{
            color: white;
            background: #22262e;
            border:2px;
        }

        """
        return self.stylesheet

    def bridge_StyleSheet(self):
        #323232 : h2 : groupbox background
        #262626 : h1 : main window background
        #3b3b3b :    : notePad text area
        # white : text color
        self.styleSheet1 = """

        QMainWindow{
            color: red; /*  for debug */
            background: #262626;
        }

        QMenuBar::item{
            /*background-color: orange;*/
        }

        QMenuBar::item:selected{
            background: #3b3b3b;
            color: white;
        }

        QMenu{
            background-color: #262626;
        }
        QMenu::item{
            background-color: #323232;
            color: white;
        }
        QMenu::item:selected{
            background-color: #3b3b3b;
        }
        QAction::data{
            background-color: blue;
            color: red;
        }

        QMenuBar{
            color: white;
            background: #323232;
        }

        QAction{
            color: white;
            background: #323232;
        }

        QGroupBox{
            color: white;
            background: #323232;
            border-radius: 1px;
            border-width: 3px;
            border-style: solid;
            border-color: #323232;
        }

        QGroupBox#manageWIP{
            color: white;
            background: #323232;
            border-radius: 5px;
            border: 3px solid orange;
        }

        QGroupBox#commandLine{
            background: #262626;
            border: 0px solid green;
        }

        QListWidget{
            color: white;
            background: #323232;
            border:2px;
        }

        QStatusBar{
            color: white;
        }

        QTextEdit#rpg{
            color: white;
            background: #3b3b3b;
            border-radius: 9px;
            margin: 10px;
            padding: 30px 10px 30px 30px;
        }

        QTextEdit#WIPnotes{
            color: white;
            background: #3b3b3b;
            border-radius: 9px;
            margin: 10px;
            padding: 30px 10px 30px 30px;
        }

        QTextEdit#commandLine{
            background: #3b3b3b;
            color: gray;;
            border: 0px solid blue;
        }

        QLineEdit#manageWIP{
            color: gray;
            border: 2px solid white;
            padding: 5px 5px 5px 5px;
            border-radius: 5px;
        }

        QListWidget#mygrey{
            color: white;
        }

        QLabel{
            color: white;
        }

        QStatusBar{
            color: gray;
        }

        QScrollBar:vertical {
            border: 0px;
            background: #323232;
            width: 10px;
        }

        QScrollBar::handle:vertical {
            background: #262626;
            border-radius: 4;

        }

        QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
            background: #323232;
            border:0;
        }

        QScrollBar:horizontal {
            border: 0px;
            background: #323232;
            width: 10px;
        }

        QScrollBar::handle:horizontal {
            background: #262626;
            border-radius: 4;

        }

        QScrollBar::add-page:horizontal, QScrollBar::sub-page:vertical {
            background: #323232;
            border:0;
        }

        QToolTip{
            color: white;
            border: 0px;
            background: #262626;
        }

        QTreeView{
            color: white;
            background: #323232;
            border:2px;
        }

        QComboBox{
            color: white;
            background: #262626;

            border: 5px solid #323232;
            /*border-radius: 1px;*/
            padding: 0px 5px 0px 10px;
            min-width: 6em
        }

        QComboBox:on{                                                           /*  combo box quand elle est dépliée*/
            color: white;
            background: #262626;
        }

        QComboBox::drop-down{
            background: orange;

        }

        QComboBox QAbstractItemView{
            color: orange;
            background: #262626;
            border: 3px solid #323232;
        }

        QTabWidget::pane{
            color: orange;
            background: orange;
        }

        QTabWidget::tab-bar{
            left: 0px;
        }

        QTabBar::tab{
            color: gray;
            background:#323232;
            border: 1px solid #262626;
            border-radius: 4px;
            min-width: 5em;
            min-height: 5px;
            height: 25px;
        }

        QTabBar::tab:selected{
            color: white;
            background: orange;
        }

        QWidget#tabBar{
            background: #323232;
        }

        QPushButton#switch:hover{
            color: white;
            background: orange;
            border: 4px solid orange;
            border-radius: 3px;
        }

        QPushButton#switch{
            color: gray;
            background:#323232;
            border: 1px solid #262626;
            border-radius: 4px;
            min-width: 5em;
            min-height: 5px;
            height: 25px;
        }

        QPushButton#normal{
            color: white;
            background: orange;
            border: 4px solid orange;
            border-radius: 3px;
        }

        QPushButton#normal:hover{
            color: white;
            background: orange;
            border: 3px solid #d57300;
            border-radius: 3px;
        }

        QPushButton#iconOnly{
            color: white;
            background: orange;
        }

        QPushButton#iconOnly:hover{
            color: white;
            background: orange;
            border: 2px solid #323232;
            border-radius: 3px;
        }




        """
        return self.styleSheet1
