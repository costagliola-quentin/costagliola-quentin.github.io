from maya import cmds as mc
import maya.mel as mel
import os, functools, sys
import webbrowser   #in order to open an url.

import Pollux_Pyside2_UI
reload(Pollux_Pyside2_UI)

from PySide2 import QtCore, QtWidgets, QtGui



USERAPPDIR = mc.internalVar(userAppDir=True)
VERSION = mc.about(v=True)
IconsPath = os.path.join(USERAPPDIR, VERSION+'/scripts/Pollux/Icons')
ImagesPath = os.path.join(USERAPPDIR, VERSION+'/scripts/Pollux/Images')


'''
#####################
####    TO DO    ####
#####################

# UVs settings

# speed lights : on selectinne les attributs qu'un veut, on les edit dans pollux et quand on clique sur creer ca le fait tout seul.

'''


class Events(object):
    """docstring for Events."""

    def __init__(self):
        #super(Events, self).__init__()
        pass

        #duplicate special global variables
        '''
        duplicate_geo_state = True
        duplicate_symmetry_state = False
        duplicate_symmetry_axis = 1
        '''



    def win_exist(self, window):
        '''checks if the main window already exists'''
        if mc.window(window, query=True, exists=True):
            mc.deleteUI(window, window=True)

    def feedback(self, feedback_str):
        print (('\nPollux => ') + feedback_str + ('\n'))


    ######################################
    #       WINDOW DIMENSIONS
    ######################################




    ##########################
    #       BUTTONS
    ##########################
    #display

    def switch_attribute_editor_channel_box_events(self, _):
        mel.eval('ShowAttributeEditorOrChannelBox;')
        self.feedback('panel switched')

    def wireframeOnShaded_display_On_events(self, _):
        #mel.eval('modelPanelBarShadingCallback("WireframeOnShadedBtn", "MainPane|viewPanes|modelPanel4|modelPanel4|modelPanel4", "MainPane|viewPanes|modelPanel4|modelPanel4|modelEditorIconBar"); restoreLastPanelWithFocus();')
        self.feedback('Wire on')

    def wireframeOnShaded_display_Off_events(self, _):
        self.feedback('Wire off')

    def pollux_pyside(self):
        '''     PYSIDE BUILDING '''

        pxui2 = Pollux_Pyside2_UI.px_UI_pyside()



        #z=QtWidgets.QMainWindow()
        #z.show()



    #tools

    def delete_history_events(self):
        mel.eval('DeleteHistory')

    def freeze_transform_events(self):
        mel.eval('FreezeTransformations;')

    def center_pivot_events(self):
        mel.eval('CenterPivot')

    def b_to_a_events(self):
        mel.eval('MatchTranslation; MatchRotation;')

    def duplicate_special_events(self):
        mel.eval('DuplicateSpecialOptions')

    def reset_pivot_events(self):
        bool = 'true'
        mel.eval('manipPivotReset '+bool+' true')

    def uv_automatic_events(self):
        mel.eval('UVAutomaticProjection;')
        self.feedback('Automatic UV projection')

    def break_all_connections_events(self):
        #channelBoxCommand -break;
        mesh = mc.ls(selection=True)

        print(mesh)

        mel.eval('CBdeleteConnection "' + mesh +'.tx";')
        mel.eval('CBdeleteConnection "' + mesh +'.ty";')
        mel.eval('CBdeleteConnection "' + mesh +'.tz";')
        mel.eval('CBdeleteConnection "' + mesh +'.rx";')
        mel.eval('CBdeleteConnection "' + mesh +'.ry";')
        mel.eval('CBdeleteConnection "' + mesh +'.rz";')
        mel.eval('CBdeleteConnection "' + mesh +'.sx";')
        mel.eval('CBdeleteConnection "' + mesh +'.sy";')
        mel.eval('CBdeleteConnection "' + mesh +'.sz";')
        mel.eval('CBdeleteConnection "' + mesh +'.v";')

        self.feedback('All connections has been closed')

    def instance_to_object_events(self):
        mel.eval('convertInstanceToObject;')
        self.feedback('Instance converted')

    #DUPLICATE
    #duplicate special variables
    global duplicate_geo_state
    duplicate_geo_state = True      #   True=Instance       False=Copy

    global duplicate_symmetry_state
    duplicate_symmetry_state = False

    global duplicate_symmetry_axis
    duplicate_symmetry_axis = 1

    def duplicate_special_v2_events(self, arg, geo_type_state= None, symmetry_state= None, symmetry_axis= None, dup_run= None):

        global duplicate_geo_state
        global duplicate_symmetry_state
        global duplicate_symmetry_axis

        if geo_type_state == False:
            duplicate_geo_state = False
        if geo_type_state == True:
            duplicate_geo_state = True

        if symmetry_state == True:
            duplicate_symmetry_state = True
        if symmetry_state == False:
            duplicate_symmetry_state = False


        if symmetry_axis == 1:
            duplicate_symmetry_axis = 1
        if symmetry_axis == 2:
            duplicate_symmetry_axis = 2
        if symmetry_axis == 3:
            duplicate_symmetry_axis = 3

        #debug:
        '''
        print(['geo_type_state'] + [geo_type_state])
        print(['symmetry_state'] + [symmetry_state])
        print(['symmetry_axis'] + [symmetry_axis])

        print(['duplicate_geo_state'] + [duplicate_geo_state])
        print(['duplicate_symmetry_state'] + [duplicate_symmetry_state])
        print(['duplicate_symmetry_axis'] + [duplicate_symmetry_axis])
        '''

    def duplicate_special_run(self):
        global duplicate_geo_state
        global duplicate_symmetry_state
        global duplicate_symmetry_axis
        instance= 'instance'
        copy= 'duplicate -rr '
        scale_x= 'scale -r -1 1 1'
        scale_y= 'scale -r 1 -1 1'
        scale_z= 'scale -r 1 1 -1'
        type=copy
        symmetry= ''

        if duplicate_geo_state == True:
            type= instance

        if duplicate_geo_state == False:
            type= copy

        if duplicate_symmetry_state == True:
            if duplicate_symmetry_axis == 1:
                symmetry = scale_x
            if duplicate_symmetry_axis == 2:
                symmetry = scale_y
            if duplicate_symmetry_axis == 3:
                symmetry = scale_z

        mel.eval(type + '; ' + symmetry)
        self.feedback('Duplicate special')

    def duplicate_special_options_events(self):
        mel.eval('DuplicateSpecialOptions;')
        self.feedback('Duplicate special options')

    #EDGE FLOW
    def multiCutToolEdgeFlow_ON(self, _):
        mel.eval('nexOpt -e useEdgeFlow true; floatSliderGrp -e -en true nexEdgeFlowFloatField;')
        print ('=> edge flow : on')
    def multiCutToolEdgeFlow_OFF(self, _):
        mel.eval('nexOpt -e useEdgeFlow false; floatSliderGrp -e -en false nexEdgeFlowFloatField;')
        print ('=> edge flow : off')

    def connectToolEdgeFlow_ON(self, _):
        selection = mc.ls(selection=True, flatten = True, dagObjects = True, type= 'polySplit')
        #mc.setAttr('pCube1.polySplit1', insertWithEdgeFlow= 1)
        #cmds.setAttr( 'sphere.translateX', lock=True )
        #setAttr "polySplit2.insertWithEdgeFlow" 1
        #print (selection)
        #print(selection[0])
        self.feedback('connectToolEdgeFlow_ON')
        mc.warning( "test warning" )


    def connectToolEdgeFlow_OFF(self, _):
        self.feedback('connectToolEdgeFlow_OFF')

    #Polygons tools

    def polySphere_events(self):
        mel.eval('polySphere -r 1 -sx 20 -sy 20 -ax 0 1 0 -cuv 2 -ch 1; objectMoveCommand;')

    def polyCylinder_events(self):
        mel.eval('polyCylinder -r 1 -h 2 -sx 40 -sy 1 -sz 1 -ax 0 1 0 -rcp 0 -cuv 3 -ch 1; objectMoveCommand;')

    def polyCube_events(self):
        mel.eval('polyCube -w 1 -h 1 -d 1 -sx 1 -sy 1 -sz 1 -ax 0 1 0 -cuv 4 -ch 1; objectMoveCommand;')

    def polyPlane_events(self):
        mel.eval('polyPlane -w 1 -h 1 -sx 1 -sy 1 -ax 0 1 0 -cuv 2 -ch 1; objectMoveCommand;')


    def polyUnite_events(self):
        mel.eval('polyPerformAction polyUnite o 0')

    def polySeparate_events(self):
        mel.eval('SeparatePolygon')

    def polySplitVertex_events(self):
        mel.eval('DetachComponent')

    def polyChipOff_events(self):
        mel.eval('performPolyChipOff 0 0')


    def polyNormal_events(self):
        mel.eval('ReversePolygonNormals')

    def polySoftEdge_events(self):
        mel.eval('SoftPolyEdgeElements 1')

    def polyHardEdge_events(self):
        mel.eval('SoftPolyEdgeElements 0')

    def polyNormalAverage_events(self):
        mel.eval('PolygonSoftenHarden')


    def show_selected_events(self):
        mel.eval('ShowSelectedObjects')

    def show_all_events(self):
        mel.eval('ShowAll')

    def lattice_events(self):
        mel.eval('CreateLattice')

    def bend_events(self):
        mel.eval('Bend')

    #Lookdev
    def aiAreaLight_events(self):
        import mtoa.utils
        mtoa.utils.createLocator("aiAreaLight", asLight=True)

        mc.select(all=False)

        current_selection = mc.ls(selection=True, dagObjects=True, shapes=True)
        lightToChange_name = current_selection[0]

        #print (current_selection[0])

        #attribToChange = "\"" + lightToChange_name + ".intensity\""
        #mc.setAttr ("aiAreaLight1.intensity", 11)
        mc.setAttr (current_selection[0] + ".intensity", 11)

    def aiSkyDomeLight_events(self):
        import mtoa.utils
        import mtoa.utils;mtoa.utils.createLocator("aiSkyDomeLight", asLight=True)

    def materialAttributes_events(self):
        mel.eval('ShowShadingGroupAttributeEditor')

    def aiStandard_events(self):
        mel.eval('createAndAssignShader aiStandardSurface "";')

    def lookdev_detail_events(self, _, btn_state):
        if btn_state == True:
            mc.formLayout()
            mc.iconTextButton(style='iconOnly', image1='Pollux/ai_standard_surface.png')
            print ('hello world')
        else :
            print ('fuck world')

    #UVs tools
    def automatic_uv_events(self):
        mel.eval('UVAutomaticProjection;')

    def planar_uv_events(self):
        mel.eval('polyProjection -ch 1 -type Planar -ibd on -kir  -md z ;')

    def spherical_uv_events(self):
        mel.eval('polyProjection -ch 1 -type Spherical -ibd on -sf on ;')

    def cylindrical_uv_events(self):
        mel.eval('polyProjection -ch 1 -type Cylindrical -ibd off -sf on ;')

    def uv_toolkit_events(self):
        mel.eval('toggleUVToolkit;')

    def layout_uv_events(self):
        mel.eval('LayoutUV;')

    def unfold_uv_events(self):
        mel.eval('UnfoldUV;')

    #Windows tools
    def arnold_events(self):
        import mtoa.ui.arnoldmenu;mtoa.ui.arnoldmenu.arnoldOpenMtoARenderView()

    def hypershade_events(self):
        mel.eval('HypershadeWindow')

    def textureEditor_events(self):
        mel.eval('TextureViewWindow')
    #
    def preferencesWindow_events(self):
        mel.eval('PreferencesWindow')

    def hotkeyPreferencesWindow_events(self):
        mel.eval('HotkeyPreferencesWindow')

    def colorPreferencesWindow_events(self):
        mel.eval('ColorPreferencesWindow')

    def shelfPreferencesWindow_events(self):
        mel.eval('ShelfPreferencesWindow')

    def renderSettingsWindow_events(self):
        mel.eval('RenderGlobalsWindow')

    def scriptEditorWindow_events(self):
        mel.eval('ScriptEditor')

    ######################
    #   MENU BAR
    ######################
    def set_project_events(self,_=None):
        mel.eval('SetProject;')
        self.feedback('Project set')

    def set_project_events_NEWUI(self):
        mel.eval('SetProject;')
        self.feedback('Project set')

    def set_current_project_Woody_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0000_Woody/01_Maya";')
        self.feedback('Woody project set')
        mc.warning("Woody project set")

    def set_current_project_Lasercannon_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0008_Maya_mb_Intermediate_Lasercannon/Lasercannon_Maya";')
        self.feedback('Lasercannon project set')
        mc.warning("Lasercannon project set")

    def set_current_project_KZ4_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0010_Maya_mb_Intermediate_Kerrigan/01_Maya";')
        self.feedback('Kerrigan project set')
        mc.warning("Kerrigan project set")

    def set_current_project_TarantulaHeavyBolters_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0013_TarantulaHeavyBolters/01_Maya";')
        self.feedback('TarantulaHeavyBolters project set')
        mc.warning("TarantulaHeavyBolters project set")

    def set_current_project_Minion_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0015_SummerSchoolArtFX_Minion/01_Maya";')
        self.feedback('Minion project set')
        mc.warning("Minion project set")

    def set_current_project_FlashGrenade_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0032_maya_flash-grenade/01_Maya";')
        self.feedback('FlashGrenade project set')
        mc.warning("FlashGrenade project set")


    def set_current_project_SecurityCamera_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0042_Maya_SecurityCamera/01_Maya";')
        self.feedback('Security Camera project set')
        mc.warning("Security Camera project set")

    def set_current_project_Dice_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0054_Maya_Dice/01_Maya";')
        self.feedback('Dice project set')
        mc.warning("Dice project set")

    def set_current_project_DeLorean_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0056_Maya_DeLorean/01_Maya";')
        self.feedback('DeLorean project set')
        mc.warning("DeLorean project set")

    def set_current_project_Hangars_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0057_Maya_Hangars/01_Maya";')
        self.feedback('Hangars project set')
        mc.warning("Hangars project set")

    def set_current_project_Orion_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0062_Maya_Orion/01_Maya";')
        self.feedback('Orion project set')
        mc.warning("DeLorean project set")

    def set_current_project_TheTrain_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0064_Maya_TheTrain/01_Maya";')
        self.feedback('TheTrain project set')
        mc.warning("TheTrain project set")

    def set_current_project_Fuze_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/Projet_Fuze/01_Maya";')
        self.feedback('Fuze project set')
        mc.warning("Fuze project set")

    def set_current_project_StrangerEngine_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0043_Maya_Strange_Engine/01_Maya";')
        self.feedback('Strange engine project set')
        mc.warning('Strange engine project set')

    def set_current_project_Mimic_events(self, _=None):
        mel.eval('setProject "D:/VFX/Projects/Work_In_Progress/0059_Houdini_Mimic/01_Maya";')
        self.feedback('Mimic project set')
        mc.warning('Mimic project set')

    def maya_help_events(self, _=None):
        webbrowser.open('http://help.autodesk.com/view/MAYAUL/2018/ENU/')
        self.feedback('Maya help')

    def maya_help_events_NEWUI(self):
        webbrowser.open('http://help.autodesk.com/view/MAYAUL/2018/ENU/')
        self.feedback('Maya help')

    def python_help_events(self, _=None):
        webbrowser.open('http://help.autodesk.com/view/MAYAUL/2018/ENU/?guid=__CommandsPython_index_html')
        self.feedback('Maya help project set')

    def python_help_events_NEWUI(self):
        webbrowser.open('http://help.autodesk.com/view/MAYAUL/2018/ENU/?guid=__CommandsPython_index_html')
        self.feedback('Maya help project set')

    def qt_detailed_description_help_events(self, _= None):
        webbrowser.open('https://doc.qt.io/qtforpython/PySide2/QtCore/Qt.html')
        self.feedback('Qt detailed description')

    def mel_help_events(self, _=None):
        webbrowser.open('http://help.autodesk.com/view/MAYAUL/2018/ENU/?guid=__Commands_index_html')
        self.feedback('Maya help project set')

    def mel_help_events_NEWUI(self):
        webbrowser.open('http://help.autodesk.com/view/MAYAUL/2018/ENU/?guid=__Commands_index_html')
        self.feedback('Maya help project set')





    ######################
    #   OTHER WINDOWS
    ######################

    def about_pollux_events(self, _=None):

        self.about_win_width = 220
        self.about_win_height = 75

        self.win_exist(window= 'about_win') #garder ca en premier sinon problemes
        self.about_win = mc.window('about_win', title= 'About Pollux')
        mc.window('about_win', e=True, widthHeight=(self.about_win_width, self.about_win_height))

        about_lyt= mc.formLayout(w=self.about_win_width, h=self.about_win_height)
        about_l1= mc.text(label='Pollux 1.1.0')
        mc.formLayout(about_lyt, edit=True, attachForm= [(about_l1, 'top', 5), (about_l1, 'left', 8)])
        about_l2= mc.text(label='Created by Cosius ')
        mc.formLayout(about_lyt, edit=True, attachForm= [(about_l2, 'top', 25), (about_l2, 'left', 8)])
        about_l3= mc.text(label='No copyright - 2019')
        mc.formLayout(about_lyt, edit=True, attachForm= [(about_l3, 'top', 45), (about_l3, 'left', 8)])

        cosius= mc.image(image=(IconsPath + '/about_portrait.png'))
        mc.formLayout(about_lyt, edit=True, attachForm= [(cosius, 'top', 5), (cosius, 'left', 150)])

        mc.showWindow(self.about_win)
        self.feedback('Pollux about window opened')


    def dev_options_events(self, _):

        #WINDOW
        self.win_exist(window= 'dev_win')
        self.dev_win = mc.window('dev_win', title='Developper options')
        mc.showWindow(self.dev_win)

        #CONTENT

        self.feedback('dev options windows opened |or not lol ;-)')

    def openNewViewport(self):
        MyLabel = 'My Panel'
        mc.window(title = "Cosius Viewport")
        mc.frameLayout( lv=0 )
        mc.modelPanel( label=MyLabel )
        mc.showWindow()

    def dev_tests_events(self):
        self.win_exist(window= 'dev_tests_win')
        self.dev_tests_win = mc.window('dev_tests_win', title = '- Tests -')
        mc.showWindow(self.dev_tests_win)
        mc.scrollLayout()


        test_win_lyt = mc.rowColumnLayout()

        mc.rowColumnLayout(test_win_lyt, edit= True, numberOfRows= 2, columnSpacing=[1,15])
        mc.rowColumnLayout(test_win_lyt, edit= True, numberOfColumns=2)
        mc.rowColumnLayout(test_win_lyt, edit=True, rowAttach=([1, "top", 1],[2, "top", 1]))

        mc.text(label = 'TESTS tab :')
        mc.separator(height=10, style='in')
        mc.text(label = 'test :')
        mc.textField(height = 50)
        mc.textField(height = 50)



        mc.separator(height=30, style='out')

        mc.columnLayout()
        mc.scrollLayout()

        mc.iconTextScrollList("frenchList", allowMultiSelection=False)
        frenchWords = ["manger", "etre"]
        mc.iconTextScrollList("englishList", allowMultiSelection=False)
        englishWords = ["eat", "be"]

        for i in range (0, 2):
            mc.iconTextScrollList("frenchList", edit=True, append=(frenchWords[i]))

        for j in range (0, 2):
            mc.iconTextScrollList("englishList", edit=True, append=(englishWords[j]))



    ######################
    #    Save Manager
    ######################

    #je veut une entree qui demande a l'utilisateur de saisir un nom de fichier et quand j'appuie sur entree sa sauvegarde la ou le projet est set
    def saveManager(self):
        self.win_exist(window= 'saveManager_win')
        self.dev_tests_win = mc.window('saveManager_win', title = '- Save manager -')
        mc.window('saveManager_win', e=True, w=200, h=200)
        mc.showWindow(self.dev_tests_win)
        #layout
        lyt_001 = mc.formLayout(w=200, h=60)

        #SAVE
        saveTitle = mc.text(l='Save :')
        saveInput = mc.textField(w=100)
        mc.formLayout(lyt_001, edit=True, attachForm=[saveTitle, 'top', 5])
        mc.formLayout(lyt_001, edit=True, attachForm=[saveTitle, 'left', 10])
        mc.formLayout(lyt_001, edit=True, attachForm=[saveInput, 'top', 20])
        mc.formLayout(lyt_001, edit=True, attachForm=[saveInput, 'left', 10])

        def save_takeText(self):
            test = mc.textField(saveInput, query=True, text=True)
            mc.file(rename=(test + '.mb'))
            mc.file(save=True, type='mayaBinary')

        mc.textField(saveInput, edit=True, enterCommand=save_takeText, text = 'Save_name')

        #OPEN
        openTitle = mc.text(l='Open : ')
        openInput = mc.textField(w=100)
        mc.formLayout(lyt_001, edit=True, attachForm=[openTitle, 'top', 50])
        mc.formLayout(lyt_001, edit=True, attachForm=[openTitle, 'left', 10])
        mc.formLayout(lyt_001, edit=True, attachForm=[openInput, 'top', 65])
        mc.formLayout(lyt_001, edit=True, attachForm=[openInput, 'left', 10])

        def open_takeText(self):
            openFileName = mc.textField(openInput, query=True, text=True)
            mc.file((openFileName + '.mb'), open=True)

        mc.textField(openInput, edit=True, enterCommand=open_takeText, text = 'open')

        filepath = mc.file(q=True, sn=True)
        filename = os.path.basename(filepath)
        #raw_name = os.path.splitext(filename)
        #print (raw_name[0]+raw_name[1])
        print(filename)



        self.feedback('test window shown')


    def textfield_events(self, text):
        self.file_info_write_events(text_to_write=text)

    def scrollField_events(self, arg, text):
        self.file_info_write_events(text_to_write=text)
        print("voila le texte :")
        print(text)

    def file_info_write_events(self, text_to_write):
        with open('C:/Users/Cosius/Documents/maya/2018/scripts/Pollux/Pollux_Infos.txt', 'w') as f:
            f.write(text_to_write)

    def file_info_read_events(self):
        #mc.file('C:/Users/Cosius/Documents/maya/2018/scripts/Pollux/test.txt')
        with open('C:/Users/Cosius/Documents/maya/2018/scripts/Pollux/Pollux_Infos.txt', 'r') as f:
            #print(f.name)
            #print(f.mode)
            #print(f.read())
            return f.read()
