import os, sys

import maya.mel as mel
from maya import cmds as mc

USERAPPDIR = mc.internalVar(userAppDir=True)
VERSION = mc.about(v=True)
IconsPath = os.path.join(USERAPPDIR, VERSION+'/scripts/Pollux/Icons')


class file_manager(object):
    """docstring for file_manager."""

    def __init__(self):
        pass


    def read_file(self, file_to_read):
        pass

    def print_text(self, text):
        print (text)

def my_file_manager():
    print('hello')
