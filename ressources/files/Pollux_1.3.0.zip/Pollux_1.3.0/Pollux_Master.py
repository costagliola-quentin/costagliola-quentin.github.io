import sys, os, functools

import Pollux_UI
reload(Pollux_UI)
from Pollux_UI import layouts as lt

import Pollux_Events
reload(Pollux_Events)

import Pollux_Pyside2_UI# as pxside
reload(Pollux_Pyside2_UI)

from Pollux_Events import Events as pxEvents
#from Pollux_Pyside2_UI import Pollux_Pyside2_UI as pxPyside

from PySide2 import QtGui, QtWidgets, QtCore
from maya import cmds as mc
import maya.mel as mel


USERAPPDIR = mc.internalVar(userAppDir=True)
VERSION = mc.about(v=True)
IconsPath = os.path.join(USERAPPDIR, VERSION+'/scripts/Pollux/Icons')
ImagesPath = os.path.join(USERAPPDIR, VERSION+'/scripts/Pollux/Images')

def text_jsp_cmt_le_name(arg, text_to_print):
    with open('C:/Users/Cosius/Documents/maya/2018/scripts/Pollux/Pollux_Infos.txt', 'w') as f :
        print(text_to_print)
        a=Pollux
        #loul = Pollux_UI.test()
        #test().Pollux_UI
        f.write(text_to_print)
        f.write('test')
        print('ok')
    print(text_to_print)

class Pollux_UI(object):
    """All the UI."""

    def __init__(self):
        super(Pollux_UI, self).__init__()



        #module instances
        self.events = pxEvents()
        #is window visible?
        self.events.win_exist(window='Pollux')
        self.events.win_exist(window='about_win')
        try:
            if mc.workspaceControl('Pollux', query=True, visible=True):
                mc.workspaceControl('Pollux', edit=True,  close=True)
        except RuntimeError:
            pass

        self.pollux_window()
        self.pollux_file_manager()


        '''
        y=QtWidgets.QDialog()
        y.show()
        '''






    def pollux_window(self):  #taille, title...
        name = 'Pollux'
        my_workspace = mc.workspaceControl(
            name,
            minimumWidth=210,
            retain=False,   #ultra important
            restore=True,
            label=name
        )

        self.pollux_window_content()

    def pollux_window_content(self):

        #cosius libraries instances:
        self.library = lt()

        #MENU BAR
        menuBarLayout = mc.menuBarLayout()
        mc.menu( label='Utils' )

        mc.menuItem(label='Set project', command=functools.partial(self.events.set_project_events))
        mc.menuItem( subMenu=True, label='Current projects' )
        mc.radioMenuItemCollection()
        mc.menuItem(label='Woody', radioButton=False, command=(functools.partial(self.events.set_current_project_Woody_events)))
        mc.menuItem(label='Kerrigan', radioButton=False, command=(functools.partial(self.events.set_current_project_KZ4_events)))
        mc.menuItem(label='SecurityCamera', radioButton=False, command=(functools.partial(self.events.set_current_project_SecurityCamera_events)))
        mc.menuItem(label='Dice', radioButton=False, command=(functools.partial(self.events.set_current_project_Dice_events)))
        mc.menuItem(label='DeLorean', radioButton=False, command=(functools.partial(self.events.set_current_project_DeLorean_events)))
        mc.menuItem(label='Mimic', radioButton=False, command=(functools.partial(self.events.set_current_project_Mimic_events)))
        mc.menuItem(label='Orion', radioButton=False, command=(functools.partial(self.events.set_current_project_Orion_events)))
        mc.menuItem(label='TheTrain', radioButton=False, command=(functools.partial(self.events.set_current_project_TheTrain_events)))
        mc.menuItem(label='TarantulaHeavyBolters', radioButton=False, command=(functools.partial(self.events.set_current_project_TarantulaHeavyBolters_events)))
        mc.menuItem(label='Fuze', radioButton=False, command=(functools.partial(self.events.set_current_project_Fuze_events)))
        mc.menuItem(label='FlashGrenade', radioButton=False, command=(functools.partial(self.events.set_current_project_FlashGrenade_events)))
        mc.menuItem(label='Strange engine', radioButton=False, command=(functools.partial(self.events.set_current_project_StrangerEngine_events)))
        mc.setParent('..', menu=True)
        mc.menuItem(label='Save manager', command=functools.partial(self.events.saveManager))


        mc.setParent( '..', menu=True )
        #mc.menuItem( label='Notes -TD' )

        mc.menu( label='Dev' )
        mc.menuItem( label='Options - Tools settings', command= self.events.dev_options_events)
        mc.menuItem( label='Tests', command= self.events.dev_tests_events)
        mc.menuItem( label='Restore default maya settings -TD')

        mc.menu( label='Help', helpMenu=True )
        mc.menuItem( label='About Pollux', command= self.events.about_pollux_events)
        mc.menuItem( subMenu=True, label = 'Web help')
        mc.menuItem( label='Maya help', command= self.events.maya_help_events)
        mc.menuItem( label='Python help', command= self.events.python_help_events)
        mc.menuItem( label='Mel help', command= self.events.mel_help_events)

        mc.columnLayout()
        mc.setParent( '..' )
        mc.scrollLayout()

        #######################
        #   DISPLAY LINE
        #######################
        first_lyt = mc.rowLayout(numberOfColumns=10)
        wireframeOnDisplay_display_btn = mc.iconTextCheckBox(style='iconOnly', image1 = 'WireFrameOnShaded.png', onCommand= (functools.partial(self.events.wireframeOnShaded_display_On_events)), offCommand=(functools.partial(self.events.wireframeOnShaded_display_Off_events)))
        use_lights_display_btn = mc.iconTextCheckBox(style='iconOnly', image1 = 'Light.png')
        none1_display_btn = mc.iconTextButton(style='iconOnly', enable = 1, image1 = 'BookmarkDown.png', command= (functools.partial(self.events.pollux_pyside)))
        none2_display_btn = mc.iconTextCheckBox(style='iconOnly', enable = 0, image1 = 'Pollux/blank_20x20.png')
        none3_display_btn = mc.iconTextCheckBox(style='iconOnly', enable = 0, image1 = 'Pollux/blank_20x20.png')
        none4_display_btn = mc.iconTextCheckBox(style='iconOnly', enable = 0, image1 = 'Pollux/blank_20x20.png')
        newViewport_display_btn = mc.iconTextButton(style='iconOnly', image1 = 'Pollux/new_viewport.png', command= (functools.partial(self.events.openNewViewport)))
        switch_attribute_editor_channel_box_display_btn = mc.iconTextCheckBox(style='iconOnly', image1 = 'Pollux/switch_attribute_editor_channel_box.png', changeCommand= (functools.partial(self.events.switch_attribute_editor_channel_box_events)))
        mc.setParent( '..' )

        #######################
        #   POLLUX CONTENT
        #######################
        #   TOOLS
        #######################
        self.library.default_column_layout_h00()
        self.library.default_frame_layout_h1(lyt_title=('Pollux content'))
        lyt_h2_1 = self.library.default_frame_layout_h2(lyt_title=('Tools'), is_collapsed=False)
        self.library.default_grid_layout()

        delete_history = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/delete_history.bmp',
            command= self.events.delete_history_events,
            annotation=('Delete history')
            )
        freeze_transform = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/freeze_transform.bmp',
            command= self.events.freeze_transform_events,
            annotation=('Freeze transform')
            )
        center_pivot = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/center_pivot.bmp',
            command= self.events.center_pivot_events,
            annotation=('Center pivot')
            )
        b_to_a = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/b_to_a.bmp',
            command= self.events.b_to_a_events,
            annotation=('B to A')
            )

        reset_pivot = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/reset_pivot_x32.png',
            command= self.events.reset_pivot_events,
            annotation=('Reset pivot')
            )
        uv_automatic = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/uvs_auto.png',
            command= self.events.uv_automatic_events,
            annotation=('Automatic UVs')
            )
        break_all_connections = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/break_all_connections.png',
            command= self.events.break_all_connections_events,
            annotation=('break all connections')
            )
        instance_to_object = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'instanceToObject.png',
            command= self.events.instance_to_object_events,
            annotation=('Instance to object')
            )

        mc.setParent('..')
        self.library.default_column_layout()
        self.library.default_separators()

        #DUPLICATE
        form_lyt = mc.formLayout(w= 200, h= 60)
        #duplicate_special = mc.iconTextButton(style = 'iconOnly', image1= 'Pollux/duplicate_special_x32.png', command= self.events.duplicate_special_v2_events, annotation=('Duplicate special'))
        duplicate_special = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/duplicate_special_x32.png',
            command= functools.partial(self.events.duplicate_special_run),
            annotation=('Duplicate special')
            )
        mc.radioCollection()
        duplicate_copy_rbtn = mc.radioButton(label='Copy', onCommand= (functools.partial(self.events.duplicate_special_v2_events, geo_type_state=False)))   #set geo_type_state
        duplicate_instance_rbtn = mc.radioButton(label='Insance', select=True, onCommand= (functools.partial(self.events.duplicate_special_v2_events, geo_type_state=True)))  ##set geo_type_state
        duplicate_special_options = mc.iconTextButton(style = 'iconOnly', image1= 'Pollux/duplicate_special_options_x32.png', command= self.events.duplicate_special_options_events)
        duplicate_symmetry_checkbx = mc.checkBox(label= 'Symmetry', onCommand= (functools.partial(self.events.duplicate_special_v2_events, symmetry_state=True)), offCommand= functools.partial(self.events.duplicate_special_v2_events, symmetry_state=False))
        mc.radioCollection()
        x = mc.radioButton(label='x', select= True, onCommand= (functools.partial(self.events.duplicate_special_v2_events, symmetry_axis=1)))
        y = mc.radioButton(label='y', onCommand= (functools.partial(self.events.duplicate_special_v2_events, symmetry_axis=2)))
        z = mc.radioButton(label='z', onCommand= (functools.partial(self.events.duplicate_special_v2_events, symmetry_axis=3)))
        #place the BUTTONS
        mc.formLayout(form_lyt, edit= True, attachForm= [(duplicate_special, 'top', 0)])
        mc.formLayout(form_lyt, edit= True, attachForm= [(duplicate_special_options, 'top', 0), (duplicate_special_options, 'left', 130)])
        mc.formLayout(form_lyt, edit= True, attachForm= [(duplicate_copy_rbtn, 'left', 53), (duplicate_copy_rbtn, 'top', 16)] )
        mc.formLayout(form_lyt, edit= True, attachForm= [(duplicate_instance_rbtn, 'left', 53), (duplicate_instance_rbtn, 'top', 0)])
        mc.formLayout(form_lyt, edit= True, attachForm= [duplicate_symmetry_checkbx, 'top', 40])
        mc.formLayout(form_lyt, edit= True, attachForm= [(x, 'top', 40), (x, 'left', 75)])
        mc.formLayout(form_lyt, edit= True, attachForm= [(y, 'top', 40), (y, 'left', 105)])
        mc.formLayout(form_lyt, edit= True, attachForm= [(z, 'top', 40), (z, 'left', 135)])

        #EDGE FLOW
        #layouts
        mc.setParent('..')
        mc.setParent('..')
        form_lyt_edge_flow = mc.formLayout(w= 200, h= 30)
        #text
        title_edge_flow = mc.text(label= 'Edge flow', align='left')
        #buttons
        mel.eval('nexOpt -e useEdgeFlow false; floatSliderGrp -e -en false nexEdgeFlowFloatField;')
        multi_cut_edge_flow = mc.iconTextCheckBox(label = 'Multi-cut', style='iconOnly', image1= 'multiCut_NEX32.png',enable=1, value=0,annotation = 'Multi cut edge flow',  onCommand = (functools.partial(self.events.multiCutToolEdgeFlow_ON)), offCommand = functools.partial(self.events.multiCutToolEdgeFlow_OFF))
        connect_edge_flow = mc.iconTextCheckBox(label = 'Connect', style='iconOnly', image1= 'connect_NEX32.png',enable=1, value=0,annotation = 'Connect edge flow',  onCommand = (functools.partial(self.events.connectToolEdgeFlow_ON)), offCommand = functools.partial(self.events.connectToolEdgeFlow_OFF))
        #layout
        mc.formLayout(form_lyt_edge_flow, edit= True, attachForm= [(title_edge_flow, 'top', 10)])
        mc.formLayout(form_lyt_edge_flow, edit= True, attachForm= [(multi_cut_edge_flow, 'top', 0), (multi_cut_edge_flow, 'left', 65)])
        mc.formLayout(form_lyt_edge_flow, edit= True, attachForm= [(connect_edge_flow, 'top', 0), (connect_edge_flow, 'left', 120)])
        self.library.default_separators()
        #mc.setParent('..')
        mc.setParent('..')
        mc.setParent('..')
        mc.setParent('..')
        mc.setParent('..')
        #self.library.default_frame_layout_h1(lyt_title=('Tool shelf'))

        #######################
        #   Polygons tab
        #######################
        lyt_h2_1 = self.library.default_frame_layout_h2(lyt_title=('Polygons'))
        self.library.default_grid_layout()

        polySphere = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polySphere.png',
            command= self.events.polySphere_events,
            annotation=('create polySphere')
            )
        polyCylinder = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyCylinder.png',
            command= self.events.polyCylinder_events,
            annotation=('create polyCylinder')
            )
        polyCube = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyCube.png',
            command= self.events.polyCube_events,
            annotation=('create polyCube')
            )
        polyPlane = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyMesh.png',
            command= self.events.polyPlane_events,
            annotation=('create polyPlane')
            )

        mc.setParent('..')
        self.library.default_column_layout()
        self.library.default_separators()
        self.library.default_grid_layout()

        polyUnite = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyUnite.png',
            command= self.events.polyUnite_events,
            annotation=('Combine')
            )
        polySeparate = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polySeparate.png',
            command= self.events.polySeparate_events,
            annotation=('Separate')
            )
        polySplitVertex = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polySplitVertex.png',
            command= self.events.polySplitVertex_events,
            annotation=('Detach')
            )
        polyChipOff = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyChipOff.png',
            command= self.events.polyChipOff_events,
            annotation=('Extract')
            )

        mc.setParent('..')
        self.library.default_column_layout()
        self.library.default_separators()
        self.library.default_grid_layout()

        polyNormal = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyNormal.png',
            command= self.events.polyNormal_events,
            annotation=('Reverse normals')
            )
        polySoftEdge = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polySoftEdge.png',
            command= self.events.polySoftEdge_events,
            annotation=('Soften edges')
            )
        polyHardEdge = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyHardEdge.png',
            command= self.events.polyHardEdge_events,
            annotation=('Harden edges')
            )
        polyNormalAverage = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyNormalAverage.png',
            command= self.events.polyNormalAverage_events,
            annotation=('Normal angle')
            )

        mc.setParent('..')
        self.library.default_column_layout()
        self.library.default_separators()
        self.library.default_grid_layout()

        show_selected = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/show_selected.png',
            command= self.events.show_selected_events,
            annotation=('Show selected')
            )
        show_all = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/show_all.png',
            command= self.events.show_all_events,
            annotation=('Show all')
            )
        lattice = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'lattice.png',
            command= self.events.lattice_events,
            annotation=('create Lattice')
            )
        bend = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'bendNLD.png',
            command= self.events.bend_events,
            annotation=('Create bend')
            )

        #######################
        #   UVs TAB
        #######################
        lyt_h2_2 = self.library.default_frame_layout_h2(lyt_title= ('UVs'))
        self.library.default_column_layout()

        self.library.default_column_layout()
        self.library.default_separators()
        self.library.default_grid_layout()

        automatic_uv = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyAutoProjLarge.png',
            command= self.events.automatic_uv_events,
            annotation=('automatic projection')
            )
        planar_uv = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyPlanProjLarge.png',
            command= self.events.planar_uv_events,
            annotation=('planar projection')
            )
        spherical_uv = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polySphereProjLarge.png',
            command= self.events.spherical_uv_events,
            annotation=('spherical projection')
            )
        cylindrical_uv   = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'polyCylProjLarge.png',
            command= self.events.cylindrical_uv_events,
            annotation=('cylindrical projection')
            )


        mc.setParent('..')
        self.library.default_column_layout()
        self.library.default_separators()
        self.library.default_grid_layout()


        uv_toolkit = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'toolSettings.png',
            command= self.events.uv_toolkit_events,
            annotation=('show uv toolkit')
            )
        uv_editor = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'textureEditor.png',
            command= self.events.textureEditor_events,
            annotation=('show uv editor')
            )
        layout_uv = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'layoutUV.png',
            command= self.events.layout_uv_events,
            annotation=('layout UVs')
            )
        unfold_uv = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/none.bmp',
            command= self.events.unfold_uv_events,
            annotation=('unfold UVs')
            )



        #######################
        #   Lookdev TAB
        #######################
        lyt_h2_2 = self.library.default_frame_layout_h2(lyt_title= ('Lookdev'))
        self.library.default_column_layout()
        self.library.default_grid_layout()

        aiAreaLight = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'AreaLightShelf.png',
            command= self.events.aiAreaLight_events,
            annotation=('Create aiLight')
            )
        aiSkyDomeLight = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'SkydomeLightShelf.png',
            command= self.events.aiSkyDomeLight_events,
            annotation=('Create aiSkyDomeLight')
            )
        materialAttributes = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/material-attributes.png',
            command= self.events.materialAttributes_events,
            annotation=('Show material attributes')
            )
        aiAreaLight3 = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/ai_standard_surface.png',
            command= self.events.aiStandard_events,
            annotation=('Create aiStandardSurface shader')
            )

        mc.setParent('..')


        details_rbtn = mc.checkBox(
            label= 'Details',
            onCommand= (functools.partial(self.events.lookdev_detail_events, btn_state=True)),
            offCommand= functools.partial(self.events.lookdev_detail_events, btn_state=False)
            )

        #######################
        #   WINDOW TAB
        #######################
        lyt_h2_2 = self.library.default_frame_layout_h2(lyt_title= ('Windows'), is_collapsed=False)
        self.library.default_column_layout()
        self.library.default_grid_layout()

        arnold = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/arnold.png',
            command= self.events.arnold_events,
            annotation=('Arnold render view')
            )
        hypershade = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/hypershade.png',
            command= self.events.hypershade_events,
            annotation=('Hypershade')
            )
        renderSettingsWindow = mc.iconTextButton(
            style = 'iconOnly', image1= 'Pollux/render_settings.png',
            command= self.events.renderSettingsWindow_events,
            annotation=('Render Settings')
            )
        textureEditor = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/UVsEditor.png',
            command= self.events.textureEditor_events,
            annotation=('UVs Editor'))

        mc.setParent('..')
        self.library.default_column_layout()
        self.library.default_separators()
        self.library.default_grid_layout()

        preferencesWindow = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/preferences_window.png',
            command= self.events.preferencesWindow_events,
            annotation=('Preferences Window')
            )
        hotkeyPreferencesWindow = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/hotkey_preferences_window.png',
            command= self.events.hotkeyPreferencesWindow_events,
            annotation=('Hotkey Preferences Window')
            )
        colorPreferencesWindow = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/color_settings_window.png',
            command= self.events.colorPreferencesWindow_events,
            annotation=('Color Preferences Window')
            )
        #shelfPreferencesWindow = mc.iconTextButton(style = 'iconOnly', image1= 'Pollux/none.bmp', command= self.events.shelfPreferencesWindow_events, annotation=('Shelf Preferences Window'))
        scriptEditorWindow = mc.iconTextButton(
            style = 'iconOnly',
            image1= 'Pollux/script_editor_window.png',
            command= self.events.scriptEditorWindow_events,
            annotation=('scriptEditorWindow')
            )

        mc.setParent('..')
        self.library.default_column_layout()
        self.library.default_separators()
        '''
        mc.textField(
            insertText=self.events.file_info_read_events(),  #lire le fichier et ecrire le contenu
            height = 40,
            changeCommand = self.events.textfield_events)
        '''
        #__________________________________________________________________________________________________________________

        enter_text = mc.scrollField('enter_text', insertText=self.events.file_info_read_events())   #affiche le texte du fichier

        test_encore = mc.scrollField('enter_text', query=True, text=True)   #attribute le contenu du fichier a test_encore
        #print('voila :')
        #print(test_encore)  #ok
        #mc.scrollField('enter_text', edit=True, changeCommand=functools.partial(self.events.scrollField_events, text=test_encore)) #ecrit test_encore dans le log
        mc.scrollField('enter_text', edit=True, changeCommand=functools.partial(text_jsp_cmt_le_name, text_to_print=test_encore)) #ecrit test_encore dans le log
        #print (' encore ben vouahhhhla : ')
        #print(test_encore)

    def test(self):
        print ('ca marche')





        #_________________________________________________________________________________________________________________
    def pollux_file_manager(self):
        self.events.file_info_read_events()





'''SHADER RESEARCHES'''
#s   haders = cmds.listConnections(cmds.listHistory('pCube1',f=1),type='lambert')

'''
# get shapes of selection:
shapesInSel =  mc.ls(dag=1,o=1,s=1,sl=1)
# get shading groups from shapes:
shadingGrps = mc.listConnections(shapesInSel,type='shadingEngine')
# get the shaders:
shaders = mc.ls(mc.listConnections(shadingGrps),materials=1)
'''

def start():
    StartEvents = pxEvents()
    StartEvents.win_exist(window= 'dev_tests_win')
    StartEvents.dev_tests_events()

    StartEvents.win_exist(window= 'saveManager_win')
    StartEvents.saveManager()

    print("hello world")
    #remettre l'argument _ dans dev_tests_events
