from maya import cmds as mc

import Pollux_Events as pevents
from Pollux_Events import Events as pEvents

import functools

######################
#    WINDOWS
######################

######################
#    layouts
######################
class layouts(object):
    """docstring for layouts."""



    def __init__(self):
        super(layouts, self).__init__()


        self.grid_lyt_cell_width = 35
        #self.events = peventslol()
        self.events = pEvents()



    def default_column_layout_h00(self):
        self.column_lyt_0 = mc.columnLayout(columnAttach=('both', 0), rowSpacing=10,columnWidth=180, adjustableColumn=False)

    def default_frame_layout_h1(self, lyt_title):
        self.frame_lyt_h1_title = lyt_title
        self.frame_lyt_1 = mc.frameLayout(label = (self.frame_lyt_h1_title), backgroundColor = (0.17,0.17,0.17), cll = 0, enableKeyboardFocus = 0, labelIndent = 10, marginWidth = 4, marginHeight = 2)    #

    def default_frame_layout_h2(self, lyt_title, is_collapsed=True):
        self.frame_lyt_h2_title = lyt_title
        self.frame_lyt_2 = mc.frameLayout(label = (self.frame_lyt_h2_title), backgroundColor = (0.2,0.2,0.2), cll = 1, collapse=is_collapsed, enableKeyboardFocus = 1, labelIndent = 10, marginWidth = 4, marginHeight = 2, font='plainLabelFont', parent= self.frame_lyt_1)  #

    def default_column_layout(self):
        self.column_lyt_1 = mc.columnLayout(columnAttach=('both', 0), rowSpacing=10,columnWidth=170, adjustableColumn=False, parent=self.frame_lyt_2)

    def default_grid_layout(self):
        self.icon_gird_lyt_1 = mc.gridLayout(numberOfRows = 1, numberOfColumns = 4, cellWidthHeight= (self.grid_lyt_cell_width + 5, self.grid_lyt_cell_width + 2),  highlightColor = (1,1,1), parent= self.frame_lyt_2)

    def default_separators(self):
        self.separator_1 = mc.separator(h=2, style='double', parent= self.column_lyt_1)
