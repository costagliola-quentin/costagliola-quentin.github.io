from io import my_file_manager
my_file_manager()
