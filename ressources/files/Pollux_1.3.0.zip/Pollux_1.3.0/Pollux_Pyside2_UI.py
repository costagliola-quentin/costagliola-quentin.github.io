# -*- coding: latin-1 -*-
from PySide2 import QtWidgets, QtGui, QtCore
from maya import cmds as mc
import os, functools
import Pollux_Events
reload(Pollux_Events)
#from Pollux_Events import Events as pxEvents

import io
reload(io)
#from io import file_manager as fm

USERAPPDIR = mc.internalVar(userAppDir=True)
VERSION = mc.about(v=True)
IconsPath = os.path.join(USERAPPDIR, VERSION+'/scripts/Pollux/Icons')
ImagesPath = os.path.join(USERAPPDIR, VERSION+'/scripts/Pollux/Images')
POLLUXDIR = os.path.join(USERAPPDIR, VERSION+'/scripts/Pollux')

'''Pollux variables'''
pwin_properties = {
    "size_x":270,
    "size_y":400,
    "location_x":1000,
    "location_y":150
    }

icons = {
    "x32_size":32
    }


class px_UI_pyside(QtWidgets.QMainWindow):
    """docstring for px_UI_pyside."""

    def __init__(self):
        super(px_UI_pyside, self).__init__()
        self.events = Pollux_Events.Events()
        self.window_properties()
        self.window_content()
        #mc.workspaceControl(self)
        self.show()


    def window_properties(self):
        self.setWindowTitle('Pollux')
        self.setWindowIcon(QtGui.QIcon(IconsPath + '/Pollux_Icon.ico'))
        #self.setIconSize(QtCore.QSize(604,604))        do nothing
        #self.setCorner(QtCore.Qt.TopLeftCorner, QtCore.Qt.AllDockWidgetAreas)
        self.setDockOptions(QtCore.Qt.TopDockWidgetArea)
        self.setGeometry(pwin_properties["location_x"], pwin_properties["location_y"], pwin_properties["size_x"], pwin_properties["size_y"])
        self.setMaximumSize(pwin_properties["size_x"],pwin_properties["size_y"])


        #flag = QtWindowFlags()
        #self.setWindowFlags(flag)


    def window_content(self):

        #BUTTONS &  CONTENU
        #delete history






        self.menuBar = QtWidgets.QMenuBar(self)
        self.menuBar.setGeometry(0,0,200,100)

        self.deleteHistory_btn = QtWidgets.QPushButton(self)
        self.deleteHistory_btn.setGeometry(5, 25, icons["x32_size"], icons["x32_size"])
        self.deleteHistory_btn.setIcon(QtGui.QIcon(IconsPath + '/delete_history.bmp'))
        self.deleteHistory_btn.setIconSize(QtCore.QSize(32 , 32))
        self.deleteHistory_btn.setToolTip("<h5>delete history<h5>")
        self.deleteHistory_btn.clicked.connect(self.events.delete_history_events)   #clicked : c'est le signal

        self.freezeTransform_btn = QtWidgets.QPushButton(self)
        self.freezeTransform_btn.setGeometry(45, 25, icons["x32_size"], icons["x32_size"])
        self.freezeTransform_btn.setIcon(QtGui.QIcon(IconsPath + '/freeze_transform.bmp'))
        self.freezeTransform_btn.setIconSize(QtCore.QSize(32, 32))
        self.freezeTransform_btn.setToolTip("<h5>freeze transformations<h5>")
        self.freezeTransform_btn.clicked.connect(self.events.freeze_transform_events)

        self.centerPivot_btn = QtWidgets.QPushButton(self)
        self.centerPivot_btn.setGeometry(5, 25, icons["x32_size"], icons["x32_size"])
        self.centerPivot_btn.setIcon(QtGui.QIcon(IconsPath + '/center_pivot.bmp'))
        self.centerPivot_btn.setIconSize(QtCore.QSize(32, 32))
        self.centerPivot_btn.setToolTip("<h5>center pivot<h5>")
        self.centerPivot_btn.clicked.connect(self.events.center_pivot_events)

        self.btoa_btn = QtWidgets.QPushButton(self)
        self.btoa_btn.setGeometry(5, 25, icons["x32_size"], icons["x32_size"])
        self.btoa_btn.setIcon(QtGui.QIcon(IconsPath + '/b_to_a.bmp'))
        self.btoa_btn.setIconSize(QtCore.QSize(32, 32))
        self.btoa_btn.setToolTip("<h5>Moves the first object selected to the second object selected<h5>")
        self.btoa_btn.clicked.connect(self.events.b_to_a_events)


        self.break_all_connections_btn = QtWidgets.QPushButton(self)
        self.break_all_connections_btn.setGeometry(0, 0, icons["x32_size"], icons["x32_size"])
        self.break_all_connections_btn.setIcon(QtGui.QIcon(IconsPath + '/break_all_connections.png'))
        self.break_all_connections_btn.setIconSize(QtCore.QSize(32, 32))
        self.break_all_connections_btn.setToolTip("<h5>breaks all connections of a mesh (keys...)<h5>")
        self.break_all_connections_btn.clicked.connect(self.events.break_all_connections_events)

        self.reset_pivot_x32_btn = QtWidgets.QPushButton(self)
        self.reset_pivot_x32_btn.setGeometry(0, 0, icons["x32_size"], icons["x32_size"])
        self.reset_pivot_x32_btn.setIcon(QtGui.QIcon(IconsPath + '/reset_pivot_x32.png'))
        self.reset_pivot_x32_btn.setIconSize(QtCore.QSize(32, 32))
        self.reset_pivot_x32_btn.setToolTip("<h5>Reset pivot<h5>")
        self.reset_pivot_x32_btn.clicked.connect(self.events.reset_pivot_events)

        self.instanceToObject_btn = QtWidgets.QPushButton(self)
        self.instanceToObject_btn.setGeometry(0, 0, icons["x32_size"], icons["x32_size"])
        self.instanceToObject_btn.setIcon(QtGui.QIcon(IconsPath + '/instance_to_object'))
        self.instanceToObject_btn.setIconSize(QtCore.QSize(32, 32))
        self.instanceToObject_btn.setToolTip("<h5>Converts instanced object to normal object<h5>")
        self.instanceToObject_btn.clicked.connect(self.events.instance_to_object_events)

        self.non_attribue = QtWidgets.QPushButton(self)
        self.non_attribue.setGeometry(0, 0, icons["x32_size"], icons["x32_size"])
        self.non_attribue.setIcon(QtGui.QIcon(IconsPath + 'blank_20x20.png'))
        self.non_attribue.setIconSize(QtCore.QSize(32, 32))
        self.non_attribue.setToolTip("<h5>non_attribue<h5>")
        self.non_attribue.clicked.connect(functools.partial(self.events.feedback, feedback_str='non attribue'))

        #file menu bar
        self.file_menuBar = self.menuBar.addMenu('File')

        self.setProject_Action = QtWidgets.QAction('set project', self)
        self.setProject_Action.triggered.connect(functools.partial(self.events.set_project_events_NEWUI))
        self.file_menuBar.addAction(self.setProject_Action)
        #sub menu : current projects
        self.current_projects_subfolder = self.file_menuBar.addMenu('Current projects')

        def set_current_project(name, ID):
            self.set_project_template_Action = QtWidgets.QAction(ID+'_'+name, self)
            if ID=="0000":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_Woody_events))
            if ID=="0008":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_Lasercannon_events))
            if ID=="0010":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_KZ4_events))
            if ID=="0013":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_TarantulaHeavyBolters_events))
            if ID=="0015":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_Minion_events))
            if ID=="0032":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_FlashGrenade_events))
            if ID=="0042":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_SecurityCamera_events))
            if ID=="0054":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_Dice_events))
            if ID=="0057":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_Hangars_events))
            if ID=="0056":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_DeLorean_events))
            if ID=="0062":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_Orion_events))
            if ID=="0064":
                self.set_project_template_Action.triggered.connect(functools.partial(self.events.set_current_project_TheTrain_events))
            self.current_projects_subfolder.addAction(self.set_project_template_Action)

        set_current_project('Woody', '0000')
        set_current_project('Laser Cannon', '0008')
        set_current_project('KZ4', '0010')
        set_current_project('Tarantula Heavy Bolters', '0013')
        set_current_project('Minion', '0015')
        set_current_project('Flash Grenade', '0032')
        set_current_project('Security Camera', '0042')
        set_current_project('Dice', '0054')
        set_current_project('DeLorean', '0056')
        set_current_project('Hangars', '0057')
        set_current_project('Orion', '0062')
        set_current_project('The Train', '0064')



        #dev menu bar
        self.dev_menuBar = self.menuBar.addMenu('Dev')
        #help menu bar
        self.help_menuBar = self.menuBar.addMenu('Help')
        #about
        self.aboutHelp_Action = QtWidgets.QAction('About Help', self)
        self.help_menuBar.addAction(self.aboutHelp_Action)
        self.aboutHelp_Action.triggered.connect(functools.partial(self.events.about_pollux_events))
        #web help
        self.webHelp_subfolder = self.help_menuBar.addMenu('Web')
        #maya help
        self.mayaHelp_Action = QtWidgets.QAction('maya Help', self)
        self.webHelp_subfolder.addAction(self.mayaHelp_Action)
        self.mayaHelp_Action.triggered.connect(functools.partial(self.events.maya_help_events_NEWUI))
        #python help
        self.pythonHelp_Action = QtWidgets.QAction('Python Help', self)
        self.webHelp_subfolder.addAction(self.pythonHelp_Action)
        self.pythonHelp_Action.triggered.connect(functools.partial(self.events.python_help_events_NEWUI))
        #mel help
        self.melHelp_Action = QtWidgets.QAction('Mel Help', self)
        self.webHelp_subfolder.addAction(self.melHelp_Action)
        self.melHelp_Action.triggered.connect(functools.partial(self.events.mel_help_events_NEWUI))
        #mqtDetailedDescription
        self.qtDetailedDescription_Action = QtWidgets.QAction('Qt detailed description', self)
        self.webHelp_subfolder.addAction(self.qtDetailedDescription_Action)
        self.qtDetailedDescription_Action.triggered.connect(functools.partial(self.events.qt_detailed_description_help_events))



        self.main_VB_layout = QtWidgets.QVBoxLayout(self)
        self.main_VB_layout.setAlignment(QtCore.Qt.AlignCenter)
        self.main_VB_layout.addWidget(self.menuBar)
        #rectest = QtCore.QRect(size=(0,0))
        #rectest.moveTopLeft(QtCore.QPoint(0,50))
        #self.main_VB_layout.setGeometry(rectest)

        #LAYOUT     ajout des buttons
        self.layout = QtWidgets.QGridLayout()        #on crée le layout
        #self.layout.setOriginCorner(QtCore.Qt.BottomLeftCorner)       inutile pr l'instant
        self.layout.setAlignment(QtCore.Qt.AlignTop)
        self.layout.setRowStretch(0, 1)
        #self.layout.setAlignment(QtCore.Qt.AlignAbsolute)
        '''self.main_VB_layout.addLayout(self.layout)'''

        #self.layout.rowCount()

        self.layout.addWidget(self.deleteHistory_btn, 0, 0)          #   on ajoute le boutton 1
        self.layout.addWidget(self.freezeTransform_btn, 0, 1)         #   on ajoute le boutton 2
        self.layout.addWidget(self.centerPivot_btn, 0, 2)
        self.layout.addWidget(self.btoa_btn, 0, 3)

        self.layout.addWidget(self.break_all_connections_btn, 1, 0)
        self.layout.addWidget(self.reset_pivot_x32_btn, 1, 1)
        self.layout.addWidget(self.instanceToObject_btn, 1, 2)
        self.layout.addWidget(self.non_attribue, 1, 3)


        #WIDGET
        self.widget = QtWidgets.QWidget()                # on crée un widget
        self.widget.setLayout(self.main_VB_layout)                    # on assigne le layout à ce widget
        self.setCentralWidget(self.widget)               # mettre le widget en principale widget

        #group box
        groupBox_h1 = QtWidgets.QGroupBox("Pollux")
        groupBox_h1.setGeometry(0,0,200,100)
        groupBox_h1.setLayout(self.layout)
        #scroll
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidget(groupBox_h1)
        self.scroll.setWidgetResizable(True)
        self.scroll.setFixedHeight(200)
        self.main_VB_layout.addWidget(self.scroll)

        self.main_VB_layout.addStretch()

        #groupBox_h2 = QtWidgets.QGroupBox("Polygons")
        #groupBox_h2.setLayout(self.layout)


        self.fm = file_manager()
        self.create = self.fm.create_file(file_name='cosius')


class file_manager(object):
    """docstring for file_manager."""

    def __init__(self):
        super(file_manager, self).__init__()
        os.chdir(POLLUXDIR+'/data')

    def create_file(self, file_name='filename'):
        open(file_name+'.txt', 'a').close()







'''Qt process'''
#       1) create a window
#       2) window window properties
#       3) Main layout
#
#
#
